function baselines = getChannelBaseline(patName)

    %Detrend
    %Normalize
    %Characterize
    
    patientsAndRecords = {};
    pi = 1;
    patientsAndRecords{pi} = {'P028', 'P028', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P032', 'P032', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P033', 'P033', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P034', 'P034_BASELINE', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P036', 'P036', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P039', 'P039_BASELINE', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P040', 'P040_EXPORT', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P041', 'P041_BASELINE', 5}; pi = pi+1;
    patientsAndRecords{pi} = {'P043', 'P043', 5}; pi = pi+1;
    
    
    patientsAndRecords{pi} = {'P013', 'baseline', 6, {'_'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P016', 'baseline', 6, {'TR7', 'TR8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P018', 'ccep_20160203', 6, {'TAR7', 'TAR8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P023', 'CCEP_RUN2_20170223', 4, {'AR8', 'AR9', 'AR10'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P025', 'ccep_run20170321', 8, {'TAR8', 'TAR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P026', 'ccep_run20170518', 4, {'TOL10', 'TOL11'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P028', 'cceo_20170720_run1', 6, {'TAL7', 'TAL8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P032', 'ccep_20171208_2', 7, {'PHL9', 'AR2'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P033', 'ccep_run20180227', 6, {'TSPR3', 'TSPR4'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P034', 'ccep_run20180319', 7, {'TML1', 'TML2', 'TML3', 'TML4'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P036', 'CCEP_20180904', 6, {'TAL10', 'TAR7', 'ECR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P037', 'CCEP_20181018', 3, {'IAL4', 'IAL5'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P038', 'ccep_run20181116', 3, {'_'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P039', 'ccep_run20181129', 4, {'FBR13', 'HAR11'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P040', 'ccep_run20190115', 6, {'HAR10', 'EL7'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P041', 'ccep_20190129', 4, {'ER9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P043', 'ccep_20190220', 4, {'FBR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P045', 'ccep_20190408', 4, {'AL9', 'AL10'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P047', 'CCEP_Run1_20190724', 6, {'AL10', 'AL11'}}; pi = pi+1;

    excludeChannels = {'C3', 'C4', 'Cz', 'F3', 'F4', 'F7', 'F8', 'Fp1', 'FP1', 'Fp2', 'FP2', 'Fz', 'FZ', 'O1', 'O2', 'P3', 'P4', 'Pz', 'T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'igger', 'ekg', 'EKG', 'EMG', 'emg'};

    blPatIdx = 0;
    for searchPatIdx = 1:size(patientsAndRecords,2)
        baselinePatientName = patientsAndRecords{searchPatIdx}{1};
        if strcmp(baselinePatientName, patName)
            blPatIdx = searchPatIdx;
            break;
        end
    end
    
    if blPatIdx > 0
        signals = {};
        for recIdx = 0:patientsAndRecords{blPatIdx}{3}
            suffix = strcat('_000', num2str(recIdx));
            if(recIdx > 9)
                suffix = strcat('_00', num2str(recIdx));
            end
            recordName = strcat(patientsAndRecords{blPatIdx}{2}, suffix);
            recordPath = strcat('F:\CCEP_Data\', patientsAndRecords{blPatIdx}{1}, '\BASELINE_EEG\', patientsAndRecords{blPatIdx}{2}, suffix, '.vhdr')

            cfg = [];
            cfg.dataset = recordPath;
            data_eeg = ft_preprocessing(cfg);
            samplingRate = data_eeg.fsample;
            if samplingRate < 2000
                stop = 1;
            end

            selectedEEG_Labels = data_eeg.label(not(contains(data_eeg.label, excludeChannels)));
            nrChannels = length(selectedEEG_Labels);

            for chIdx = 1:nrChannels
                channName = selectedEEG_Labels{chIdx};
                ccepEventsToAnalyze = [];
                if not(contains(channName, excludeChannels))
                    signal = detrend(data_eeg.trial{1}(chIdx,:));           %Detrend
                    if isempty(signals)
                        signals{1,1} = channName;
                        signals{1,2} = signal;
                    else
                        idx = find(strcmp([signals(:,1)], channName)); % single line engine
                        if isempty(idx)
                            idx = size(signals,1)+1;
                        end
                        signals{idx,1} = channName;
                        signals{idx,2} = cat(2, signals{idx,2}, signal);
                    end
                end
            end
        end
        
        %Filter, Normalize and characterize
        %Filter
        order = 20;
        filterDelay = order/2;
        h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'

        baselines={};
        for si = 1:size(signals,1)
            chBaselineSignal = signals{si,2};
            
            %Filter
            filtResponse = filter(h, 1, flip(chBaselineSignal));
            filtResponse = filter(h, 1, flip(filtResponse));
            filtResponse(1:filterDelay) = filtResponse(filterDelay+1);
            chBaselineSignal(end-filterDelay:end) = filtResponse(end-filterDelay-1);

            %Normalize
            %chBaselineSignal = (chBaselineSignal - mean(chBaselineSignal))/std(chBaselineSignal);

            baselines{si,1} = signals{si,1};
            baselines{si,2} = mean(chBaselineSignal);
            baselines{si,3} = median(chBaselineSignal);
            baselines{si,4} = std(chBaselineSignal);
        end
    else
       while(1)
        error = "no Baseline"
       end
    end
    
    saveBaselines(patientName, baselines);
end

function saveBaselines(patientName, baselines)
    patientRecordPath = strcat('..\Baselines\', patientName, '\');
    mkdir(patientRecordPath);
    save(strcat(patientRecordPath, patientName, '_FilteredBaselines.mat'), 'baselines');
end

function baselines = loadBaselines(patientName)
    patientRecordPath = strcat('..\Baselines\', patientName, '\');
    load(strcat(patientRecordPath, patientName, '_FilteredBaselines.mat'), 'baselines');
end
