function [fVec wvltOut] = convCWT(fs, nrCycles, freqA, freqB, freqDelta, data)
    
    %add zero padding
    padSize = fs*10;
    padVec = zeros(1, padSize);
    data = cat(2, padVec, data, padVec);
    
    fVec = [freqA freqA+freqDelta:freqDelta:freqB-freqDelta freqB];   %get number components
    nrTimePoints = size(data, 2);                           %time points
    wvltOut = zeros(length(fVec), nrTimePoints);            %output matrix
        
    %perform transform
    parfor freqIdx = 1:length(fVec)%parfor
        f = fVec(freqIdx);
        kernel = getKernel(fs, nrCycles, f);
        kernelLength = length(kernel);
        signal = data;
        %loop over samples
        for si = 1:nrTimePoints            
            cs = si-ceil(kernelLength/2);
            ce = cs + kernelLength - 1;
            if cs < 1 || ce > nrTimePoints
                continue;
            end
            cs = int32(cs);
            ce = int32(ce);          
            wvltOut(freqIdx, si) = sum((signal(cs:ce)').*kernel);
        end
    end
    
    %remove zero padding
    wvltOut(:, 1:padSize) = [];
    wvltOut(:, end-(padSize-1):end) = [];

    plotOK = 0;
    if plotOK > 0
        time = (0:length(data)-1)/fs;
        subplot(2,1,1)
        plot(time, data)
        xlim([min(time) max(time)])

        subplot(2,1,2)
        normCFS = wvltOut.*wvltOut; 
        contour(time, fVec, normCFS, 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
        maxRC = [];
        maxVal = 0;
        for r = 1:size(normCFS,1)
            for c = 1:size(normCFS,2)
                if (normCFS(r,c) > maxVal)
                    maxVal = normCFS(r,c);
                    maxRC = [r c];
                end
            end
        end
        xlim([min(time) max(time)])
        maxTime = time(maxRC(2));
        maxFreq = fVec(maxRC(1));
    end
end

function val = sqrx(x)
    val = 0;
    if (x > 1e-36)
        val = sqrt(x);
    end
end

function kernel = getKernel(fs, nrCycles, centerFreq)
    nrCycles = 1;
	relFreq = double(centerFreq) / double(fs); %compute relative frequency for sinus function

	%determine kernel length depending on sampling frequency and center frequency
	kernelLength = (double(nrCycles) / centerFreq) * fs;
    kernelLength = int32(kernelLength);
	kernel = double(zeros(kernelLength,1));
    
    m_pi = 3.1415926535897932384626433832795;
    twoPI = 2.0 * m_pi;
    scale = 1 / (relFreq*twoPI);   % relative frequency in rad/s  (1Hz = 2*PI rad/s)
    scaleSqr = scale * scale;
    ampScale = (1.0 / sqrx(scale)) * (1.0 / sqrx(sqrx(m_pi)));
    for k = 1:kernelLength
        cosComponent = cos(relFreq * double(k) * twoPI);
        kernel(k) = cosComponent*ampScale;
    end
    kernel = -kernel;
end

