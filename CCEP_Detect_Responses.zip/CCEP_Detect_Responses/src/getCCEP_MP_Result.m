function ccepEventsToAnalyze = getCCEP_MP_Result(samplingRate, ccepEventsToAnalyze, responsesDictionary)

    %Filter
    fs = samplingRate;    order = 32;%same as baseline calculated with average channel signals
    filterDelay = order/2;
    h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
    
    parfor respIdx = 1:size(ccepEventsToAnalyze,1) %parfor
        ccepEvent = ccepEventsToAnalyze{respIdx};
        responseSignal = ccepEventsToAnalyze{respIdx}.signal;
        filtResponse = filter(h, 1, flip(responseSignal));
        filtResponse = filter(h, 1, flip(filtResponse));
        filtResponse(1:filterDelay) = filtResponse(filterDelay+1);
        filtResponse(end-filterDelay:end) = filtResponse(end-filterDelay-1);
        responseSignal = filtResponse;        
        mpResultPos = get_ResponseAtomsCorrelation(responsesDictionary, responseSignal, samplingRate);
        mpResultNeg = get_ResponseAtomsCorrelation(responsesDictionary, responseSignal*-1, samplingRate);
        ccepEvent.mpResult = {mpResultPos, mpResultNeg};
        ccepEvent.cwt = [];
        
        mpResult = mpResultPos;
        if mpResultNeg.maxCorrel > mpResultPos.maxCorrel
            mpResult = mpResultNeg;
            responseSignal = responseSignal*-1;
        end
       
        ccepEvent.components.early.info = initializeComponent();
        ccepEvent.components.late.info = initializeComponent();
        ccepEvent.components.post.info = initializeComponent();
        
        ecEvent = initializeComponent();
        minLatencySec = 0; maxLatencySec = 0.1;
        ecEvent = detectComponent(responseSignal, fs, ecEvent, responsesDictionary, mpResult, minLatencySec, maxLatencySec, 1);
        
        lcEvent = initializeComponent();
        minLatencySec = 0.1;
        if ecEvent.endSec > minLatencySec
            minLatencySec = ecEvent.endSec;
        end
        maxLatencySec = 1;
        lcEvent = detectComponent(responseSignal, fs, lcEvent, responsesDictionary, mpResult, minLatencySec, maxLatencySec, 2);

        pcEvent = initializeComponent();
        minLatencySec = 1; 
        if lcEvent.endSec > minLatencySec
            minLatencySec = lcEvent.endSec;
        end
        maxLatencySec = 3;
        pcEvent = detectComponent(responseSignal, fs, pcEvent, responsesDictionary, mpResult, minLatencySec, maxLatencySec, 3);

        %save to struct
        ccepEvent.components.early.info = ecEvent;
        ccepEvent.components.late.info = lcEvent;
        ccepEvent.components.post.info = pcEvent;
        
        
        ccepEventsToAnalyze{respIdx} = ccepEvent;
    end            
end

function cccepCpmnt = detectComponent(signal, fs, cccepCpmnt, responsesDictionary, mpResult, minLatencySec, maxLatencySec, eventType)    
           
    ecAmpLength = responsesDictionary{mpResult.atomIdx, 2};
    lcAmpLength = responsesDictionary{mpResult.atomIdx, 3};
    samplesShift = mpResult.sampleShift;
    spaceLength = responsesDictionary{mpResult.atomIdx, 4};

    if eventType == 1
        eventExists = ecAmpLength(1) > 0 && mpResult.maxCorrel > 0.6;
        eventStartSec = (1 + samplesShift)/fs;
        eventDurationSec = ecAmpLength(2)/fs;
    elseif eventType == 2
        eventExists = lcAmpLength(1) > 0 && mpResult.maxCorrel > 0.6;
        eventStartSec = (samplesShift + ecAmpLength(2) + spaceLength + 1)/fs;
        eventDurationSec = lcAmpLength(2)/fs;
    elseif eventType == 3
        eventExists = 1;
        eventStartSec = (samplesShift + ecAmpLength(2) + spaceLength + lcAmpLength(2) + 1)/fs;
        eventDurationSec = length(signal)/fs - eventStartSec;
    end
           
    cccepCpmnt.exists = eventExists;    
    cccepCpmnt.nrWaves = 0;
    cccepCpmnt.spectralPeak = 0;    
    cccepCpmnt.startSec = eventStartSec;
    cccepCpmnt.endSec = eventStartSec + eventDurationSec;

    if cccepCpmnt.startSec < minLatencySec
        cccepCpmnt.startSec = minLatencySec;
    end
    if cccepCpmnt.startSec > maxLatencySec
        cccepCpmnt.startSec = maxLatencySec;
    end
    cccepCpmnt.durationSec = cccepCpmnt.endSec-cccepCpmnt.startSec;
end

function component = initializeComponent()
    component.exists = 0;
    component.nrWaves = 0;
    component.spectralPeak = 0;    
    component.startSec = 0;
    component.endSec = 0;
    component.durationSec = 0;        
end