function ccepEventsDetectedComponents = detectCCEP_ComponentsCWT(threshold, samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir)
    
    fs = samplingRate;
    
    %Filter
    order = 32;%same as baseline calculated with average channel signals
    filterDelay = order/2;
    h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1
    
    nrECDetects = 0;
    nrLCDetects = 0;
    nrPCDetects = 0;

    for respIdx = 1:size(ccepEventsToAnalyze,1)%149, 162
        ccepEvent = ccepEventsToAnalyze{respIdx};
        
        %add this entry to the structure
        ccepEvent.components.early.info = initializeComponent();
        ccepEvent.components.late.info = initializeComponent();
        ccepEvent.components.post.info = initializeComponent();
        
        responseSignal = ccepEventsToAnalyze{respIdx}.signal;
        evIdx = ccepEventsToAnalyze{respIdx}.eventIdx;
        stimChannName = ccepEventsToAnalyze{respIdx}.stimMontageName;
        responseChannName = ccepEventsToAnalyze{respIdx}.responseChannel;
        rickardPow = ccepEventsToAnalyze{respIdx}.cwt.pow;
        rickardFreqs = ccepEventsToAnalyze{respIdx}.cwt.freq;
        
        filtResponse = filter(h, 1, flip(responseSignal));
        filtResponse = filter(h, 1, flip(filtResponse));
        filtResponse(1:filterDelay) = filtResponse(filterDelay+1);
        filtResponse(end-filterDelay:end) = filtResponse(end-filterDelay-1);
        responseSignal = filtResponse;

        if strcmp(baselineName, 'allChannAvgBL')
            baseline = ccepEvent.baseline;
        elseif strcmp(baselineName, 'lastSecBL')
            blSignal = responseSignal(end-(1*fs):end);
            baseline = {responseChannName, mean(blSignal), median(blSignal), std(blSignal)};
        end
        
        thStdDevEC = threshold;
        thStdDevLC = threshold;
        thStdDevPC = threshold;

        ecEvent = initializeComponent();
        minLatencySec = 0; maxLatencySec = 0.1; thAmpEC = baseline{3} + thStdDevEC*baseline{4};
        ecEvent = detectComponent(responseSignal, fs, thAmpEC, ecEvent, [5 30], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        if ecEvent.exists == 0
            ecEvent = detectComponent(responseSignal*-1, fs, thAmpEC, ecEvent, [5 30], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        end

        lcEvent = initializeComponent();
        minLatencySec = 0.1;
        if ecEvent.endSec > minLatencySec
            minLatencySec = ecEvent.endSec;
        end
        maxLatencySec = 1; thAmpLC = baseline{3} + thStdDevLC*baseline{4};
        lcEvent = detectComponent(responseSignal, fs, thAmpLC, lcEvent, [1 5], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        if lcEvent.exists == 0
            lcEvent = detectComponent(responseSignal*-1, fs, thAmpLC, lcEvent, [1 5], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        end

        pcEvent = initializeComponent();
        minLatencySec = 1; 
        if lcEvent.endSec > minLatencySec
            minLatencySec = lcEvent.endSec;
        end
        maxLatencySec = 3; thAmpPC = baseline{3} + thStdDevPC*baseline{4};
        pcEvent = detectComponent(responseSignal, fs, thAmpPC, pcEvent, [1 30], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        if pcEvent.exists == 0
            pcEvent = detectComponent(responseSignal*-1, fs, thAmpPC, pcEvent, [1 30], rickardPow, rickardFreqs, minLatencySec, maxLatencySec);
        end

        %save to struct
        %save to struct
        ccepEvent.components.early.info = ecEvent;
        ccepEvent.components.late.info = lcEvent;
        ccepEvent.components.post.info = pcEvent;
        
        nrECDetects = nrECDetects + ccepEvent.components.early.info.exists;
        nrLCDetects = nrLCDetects + ccepEvent.components.late.info.exists;
        nrPCDetects = nrPCDetects + ccepEvent.components.post.info.exists;

        if plotCCEP_DetectionsOK
            fig = figure(respIdx);
            time = (0:length(responseSignal)-1)/fs;
            plot(time, responseSignal, 'k'); hold on;
            baseMean = baseline{2};
            hline(baseMean, 'y', 'avg');
            hline(thAmpEC, 'm', 'ThEC');
            hline(thAmpLC, 'm', 'ThLC');
            hline(thAmpPC, 'm', 'ThPC');

            %hline(baseMean + thStdDevLC*std(baseline), 'm', 'ThLC');

            respIdx
            if ecEvent.exists == 1
                ecTime = time(ceil(ecEvent.startSec*fs):ceil(ecEvent.endSec*fs));
                ecSignal = responseSignal(ceil(ecEvent.startSec*fs):ceil(ecEvent.endSec*fs));
                plot(ecTime, ecSignal, 'r');

                ecString = {'Early Component'...
                            strcat('Nr.Waves:', num2str(ecEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(ecEvent.spectralPeak), 'Hz')...
                            strcat('Latency:', num2str(ecEvent.startSec), 's')...
                            strcat('Duration:', num2str(ecEvent.durationSec), 's')};
                eca=annotation('textbox', [0.8, 0.8, 0.1, 0.11], 'String', ecString,'FitBoxToText','on', 'BackgroundColor', 'w');
                eca.Color = 'r';
            end
            if lcEvent.exists == 1
                lcTime = time(ceil(lcEvent.startSec*fs):ceil(lcEvent.endSec*fs));
                lcSignal = responseSignal(ceil(lcEvent.startSec*fs):ceil(lcEvent.endSec*fs));
                plot(lcTime, lcSignal, 'b');
                lcString = {'Late Component'...
                            strcat('Nr.Waves:', num2str(lcEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(lcEvent.spectralPeak))...
                            strcat('Latency:', num2str(lcEvent.startSec))...
                            strcat('Duration:', num2str(lcEvent.durationSec))};
                lca=annotation('textbox', [0.8, 0.7, 0.1, 0.11], 'String', lcString,'FitBoxToText','on', 'BackgroundColor', 'w');
                lca.Color = 'b';
            end
            if pcEvent.exists == 1
                pcTime = time(ceil(pcEvent.startSec*fs):ceil(pcEvent.endSec*fs));
                pcSignal = responseSignal(ceil(pcEvent.startSec*fs):ceil(pcEvent.endSec*fs));
                plot(pcTime, pcSignal, 'Color',[1 0.412 0.161]);
                pcString = {'Post Component'...
                            strcat('Nr.Waves:', num2str(pcEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(pcEvent.spectralPeak))...
                            strcat('Latency:', num2str(pcEvent.startSec))...
                            strcat('Duration:', num2str(pcEvent.durationSec))};
                lca=annotation('textbox', [0.8, 0.6, 0.1, 0.11], 'String', pcString,'FitBoxToText','on', 'BackgroundColor', 'w');
                lca.Color = [1 0.412 0.161];
            end
            vline((0.1), 'g', '0.1s');
            vline((1), 'g', '1s');

            title(strcat('Stimulation:', stimChannName, '\_\_\_ Response:', responseChannName))
            xlim([min(time) max(time)]);

            set(gcf, 'Position', get(0, 'Screensize'));
            channPlotDir = strcat(plotsDir, 'DetectedComponents\', responseChannName, '\');
            mkdir(channPlotDir)
            figOneFileName = strcat(channPlotDir, num2str(respIdx), '_Response_', responseChannName, 'Stim_', stimChannName);
            savefig(fig, figOneFileName, 'compact');
            hgexport(fig, figOneFileName, hgexport('factorystyle'), 'Format', 'jpeg');

            close;
        end
        ccepEvent.cwt = [];
        ccepEventsToAnalyze{respIdx} = ccepEvent;
    end
    
    ccepEventsDetectedComponents = ccepEventsToAnalyze;
    
    [threshold nrECDetects nrLCDetects nrPCDetects]
end

function component = initializeComponent()
    component.exists = 0;
    component.nrWaves = 0;
    component.spectralPeak = 0;    
    component.startSec = 0;
    component.endSec = 0;
    component.durationSec = 0;        
end

function cccepCpmnt = detectComponent(signal, fs, thAmp, cccepCpmnt, freqBand, rickardPow, rickardFreqs, minLatencySec, maxLatencySec)    
    %Samples over Threshold
    posSamples = (signal >= thAmp);
    
   % are there enough consecutive positive samples?
    minNrConsecPos = (((1/freqBand(2))/2)/5)*fs;
    peakStart = 0;
    peakEnd = 0;
    for i = 1:length(posSamples)
        if peakStart == 0
            if posSamples(i) > 0
                peakStart = i;
                peakEnd = i;
            end
        else
            if posSamples(i) > 0
                peakEnd = i;
            else
                peakLength = peakEnd - peakStart + 1;
                if peakLength < minNrConsecPos
                    posSamples(peakStart:peakEnd) = 0;
                end
                peakStart = 0;
            end
        end
    end
    componentDetected = sum(posSamples) >= minNrConsecPos;
    
    if componentDetected > 0
        waves = getComponentWaves(signal, posSamples, fs, freqBand, minLatencySec, maxLatencySec);
        cccepCpmnt.exists = waves.nr > 0;
        if cccepCpmnt.exists
            waves = getWavesRickard(length(signal), fs, freqBand, waves, rickardPow, rickardFreqs);
        end
        cccepCpmnt.nrWaves = waves.nr;
        cccepCpmnt.spectralPeak = waves.sp;    
        cccepCpmnt.startSec = waves.first(2)/fs;
        cccepCpmnt.endSec = waves.last(3)/fs;
        if cccepCpmnt.startSec < minLatencySec
            cccepCpmnt.startSec = minLatencySec;
        end
        if cccepCpmnt.startSec > maxLatencySec
            cccepCpmnt.startSec = maxLatencySec;
        end
        
        cccepCpmnt.durationSec = cccepCpmnt.endSec-cccepCpmnt.startSec;
    end
end

function waves = getComponentWaves(signal, posSamples, fs, freqBand, minLatencySec, maxLatencySec)
    sl = length(posSamples);
    posSamplesIndices = find(posSamples, sl, 'first');

    %find the gaps distance in samples
    posSamplesDistances = diff(posSamplesIndices);
    posSamplesStartIndices = posSamplesIndices(2:end);
    posSamplesEndIndices = posSamplesIndices(1:end-1);


    %find the gaps between waves
    minGapDist = ((1/freqBand(2))/8)*fs;
    waveStartSamples = cat(2, posSamplesIndices(1), posSamplesStartIndices(posSamplesDistances > minGapDist));
    waveEndSamples = cat(2, posSamplesEndIndices(posSamplesDistances > minGapDist), posSamplesIndices(end));
    waveMiddleSamples = waveStartSamples + (waveEndSamples - waveStartSamples)/2.0;
    
    %delete Waves with onset after the time boundary
    minSamplesLatency = int32(minLatencySec*fs);
    maxSamplesLatency = int32(maxLatencySec*fs);
    deleteWaves = (waveMiddleSamples < minSamplesLatency) | (waveMiddleSamples > maxSamplesLatency);
    waveStartSamples(deleteWaves) = [];
    waveEndSamples(deleteWaves) = [];
    
    nrWaves = length(waveStartSamples);
    
    firstWaveMaxIdx = 0;
    firstWaveStartIdx = 0;
    firstWaveEndIdx = 0;
    lastWaveMaxIdx = 0;
    lastWaveStartIdx = 0;
    lastWaveEndIdx = 0; 
                    
    if nrWaves > 0
        firstWaveStartIdx = waveStartSamples(1);
        firstWaveEndIdx = waveEndSamples(1);
        fwsignal = signal(firstWaveStartIdx:firstWaveEndIdx);
        [maxVAl maxIdx] = max(fwsignal);
        firstWaveMaxIdx = firstWaveStartIdx + maxIdx;
        
        lastWaveStartIdx = waveStartSamples(end);
        lastWaveEndIdx = waveEndSamples(end);
        lwsignal = signal(lastWaveStartIdx:lastWaveEndIdx);
        [maxVAl maxIdx] = max(lwsignal);
        lastWaveMaxIdx = lastWaveStartIdx + maxIdx;
        if lastWaveMaxIdx == maxSamplesLatency
            stop = 1;
        end
    end
    
    waves.nr = nrWaves;
    waves.sp = 0;
    waves.first = cat(2, double([firstWaveMaxIdx firstWaveStartIdx, firstWaveEndIdx]), 0);
    waves.last = cat(2, double([lastWaveMaxIdx lastWaveStartIdx, lastWaveEndIdx]), 0);
end

function wavesRickard = getWavesRickard(signalLength, fs, componentFreqBand, waves, rickardPow, rickardFreqs)

    nrWaves = waves.nr;
    if nrWaves == 1
        firstWaveStartIdx = waves.first(2);
        firstWaveEndIdx = waves.first(3);
        firstWaveMaxIdx = waves.first(1);
        %get spectral peak
        maxPow = 0;
        spectralPeak = 0;
%         avgWavePow = mean(rickardPow(:, firstWaveStartIdx:firstWaveEndIdx), 2);
%         [maxPow spectralPeakIdx] = max(avgWavePow);
%         spectralPeak = rickardFreqs(spectralPeakIdx);
        for ti = firstWaveStartIdx:firstWaveEndIdx
            for fi = 1:length(rickardFreqs)
                freq = rickardFreqs(fi);
                if (maxPow < rickardPow(fi, ti)) && (freq >= componentFreqBand(1) && freq <= componentFreqBand(2))
                    maxPow = rickardPow(fi, ti);
                    spectralPeak = freq;
                end
            end
        end
        firspWaveSpectralPeak = spectralPeak;
        fourthWaveLength = round((1/(4*spectralPeak))*fs);
        firstWaveStartIdx = firstWaveMaxIdx - fourthWaveLength;
        firstWaveEndIdx = firstWaveMaxIdx + fourthWaveLength;
        if firstWaveStartIdx < 1
            firstWaveStartIdx = 1;
        end
        if firstWaveEndIdx > signalLength
            firstWaveEndIdx = signalLength;
        end
        
        lastWaveSpectralPeak = firspWaveSpectralPeak;
        lastWaveMaxIdx = firstWaveMaxIdx;
        lastWaveStartIdx = firstWaveStartIdx;
        lastWaveEndIdx = firstWaveEndIdx;
    else
        %%%%%%%%%%%%%%%%First Wave%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        firstWaveStartIdx = waves.first(2);
        firstWaveEndIdx = waves.first(3);
        firstWaveMaxIdx = waves.first(1);
        %get spectral peak
        maxPow = 0;
        spectralPeak = 0;
%         avgWavePow = mean(rickardPow(:, firstWaveStartIdx:firstWaveEndIdx), 2);
%         [maxPow spectralPeakIdx] = max(avgWavePow);
%         spectralPeak = rickardFreqs(spectralPeakIdx);
        for ti = firstWaveStartIdx:firstWaveEndIdx
            for fi = 1:length(rickardFreqs)
                freq = rickardFreqs(fi);
                if (maxPow < rickardPow(fi, ti)) && (freq >= componentFreqBand(1) && freq <= componentFreqBand(2))
                    maxPow = rickardPow(fi, ti);
                    spectralPeak = freq;
                end
            end
        end
        firspWaveSpectralPeak = spectralPeak;
        fourthWaveLength = round((1/(4*spectralPeak))*fs);
        firstWaveStartIdx = firstWaveMaxIdx - fourthWaveLength;
        firstWaveEndIdx = firstWaveMaxIdx + fourthWaveLength;
        if firstWaveStartIdx < 1
            firstWaveStartIdx = 1;
        end
        if firstWaveEndIdx > signalLength
            firstWaveEndIdx = signalLength;
        end
        
        %%%%%%%%%%%%%%%%Last Wave%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        lastWaveStartIdx = waves.last(2);
        lastWaveEndIdx = waves.last(3);
        lastWaveMaxIdx = waves.last(1);
        %get spectral peak
        maxPow = 0;
        spectralPeak = 0;
%         avgWavePow = mean(rickardPow(:, firstWaveStartIdx:firstWaveEndIdx), 2);
%         [maxPow spectralPeakIdx] = max(avgWavePow);
%         spectralPeak = rickardFreqs(spectralPeakIdx);
        for ti = lastWaveStartIdx:lastWaveEndIdx
            for fi = 1:length(rickardFreqs)
                freq = rickardFreqs(fi);
                if (maxPow < rickardPow(fi, ti)) && (freq >= componentFreqBand(1) && freq <= componentFreqBand(2))
                    maxPow = rickardPow(fi, ti);
                    spectralPeak = freq;
                end
            end
        end
        lastWaveSpectralPeak = spectralPeak;
        fourthWaveLength = round((1/(4*spectralPeak))*fs);
        lastWaveStartIdx = lastWaveMaxIdx - fourthWaveLength;
        lastWaveEndIdx = lastWaveMaxIdx + fourthWaveLength;
        if lastWaveStartIdx < 1
            lastWaveStartIdx = 1;
        end
        if lastWaveEndIdx > signalLength
            lastWaveEndIdx = signalLength;
        end
        
    end
    
    wavesRickard.nr = nrWaves;
    wavesRickard.sp = max(firspWaveSpectralPeak, lastWaveSpectralPeak);
    wavesRickard.first = cat(2, double([firstWaveMaxIdx firstWaveStartIdx, firstWaveEndIdx]), firspWaveSpectralPeak);
    wavesRickard.last = cat(2, double([lastWaveMaxIdx lastWaveStartIdx, lastWaveEndIdx]), lastWaveSpectralPeak);
end

function spectralPeak = fftSpectralPeak(signal, fs, band)
    signal = signal-mean(signal);
    signal = signal + abs(min(signal));
    lpad = 10*fs;
    xdft = fft(signal, lpad);
    xdft = xdft(1:lpad/2+1);            % Because the signal is real-valued, use only the positive frequencies from the DFT to estimate the amplitude
    xdft = xdft/length(signal);         % Scale the DFT by the length of the input signal
    xdft(2:end-1) = 2*xdft(2:end-1);    % multiply all frequencies except 0 and the Nyquist by 2
    xdft = real(xdft);
    freq = 0:fs/lpad:fs/2;
    
    bandSelect = (freq >= band(1) & freq <= band(2));
    xdft = xdft.*bandSelect;
    [maxVal maxIdx] = max(xdft);
    spectralPeak.f = freq(maxIdx);
    spectralPeak.p = xdft(maxIdx)*xdft(maxIdx);
end
