function [mpResult] = get_ResponseAtomsCorrelation(responsesDictionary, response, sampFreq)
       
    fs = sampFreq;
       
    mpResult.maxCorrel = double(0);
    mpResult.best_PVal = double(10);
    mpResult.atomIdx = int32(1);
    mpResult.sampleShift = int32(0);
    
    nrAtoms = size(responsesDictionary, 1);
    mpResults = double(zeros(nrAtoms,4));

    parfor ai = 1:nrAtoms %parfor    
        %shift response to center both atom and response
        atom = responsesDictionary{ai, 1};
        atomLength = length(atom);

        %shift atoms to obtain best match
        shiftLength = int32(0.02 * sampFreq); % shift up to 50ms
        maxDP = double(0);
        maxCorrel = double(0);
        bestP_Val = double(100);
        sampleShift = double(0);

        for si = 0:0.010*fs:0.05*fs
            if si+atomLength <= length(response)
                shiftedResponse = response(si+1:si+atomLength);
                %dp = dot(atom, shiftedResponse);%dot product determines vector similarity https://math.stackexchange.com/questions/689022/how-does-the-dot-product-determine-similarity
                %[rho,pval] = corr(transpose(atom), transpose(shiftedResponse), 'Type','Spearman');%'Pearson' (default) | 'Kendall' | 'Spearman'
                [rho,pval] = corr((transpose(atom)), (transpose(shiftedResponse)), 'Type','Spearman');%'Pearson' (default) | 'Kendall' | 'Spearman'

                if rho > maxCorrel && pval< 0.0001
                    maxCorrel = rho;
                    bestP_Val = pval;
                    sampleShift = si;
                end
            end
        end
        mpResults(ai, :) = [ maxDP maxCorrel bestP_Val double(sampleShift) ];
    end

    mpResult.maxCorrel = double(0);
    mpResult.best_PVal = double(10);
    mpResult.atomIdx = int32(1);
    mpResult.sampleShift = int32(0);

    for ai = 1:nrAtoms
        dp = mpResults(ai,1);
        rho = mpResults(ai,2);
        p = mpResults(ai,3);
        shift = mpResults(ai,4);

        %if rho > mpResult.maxCorrel || (rho > threshold && p < mpResult.best_PVal)
        if rho > mpResult.maxCorrel
            close;
            mpResult.maxCorrel = rho;
            mpResult.best_PVal = p;
            mpResult.atomIdx = ai;
            mpResult.sampleShift = shift;

%             atomP = rescale(responsesDictionary{ai, 1});
%             shiftedResponseP = rescale(response(shift+1:shift+length(atomP)));
%             figure(2)
%             plot(transpose(atomP)); hold on;
%             plot(transpose(shiftedResponseP)); hold on;
%             legend('Atom', 'Response');
%             title(strcat('Rho:', num2str(rho), ', p:', num2str(p), ', shift:', num2str(shift)));
        end
    end
    %close();

    if(mpResult.atomIdx < 1)
        stop = 1;
    end


end