function ccepEventsToAnalyze = detectCCEP_ComponentsFixedTimes(samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir)
    fs = samplingRate;  
    
    for respIdx = 1:size(ccepEventsToAnalyze,1)%
        ccepEvent = ccepEventsToAnalyze{respIdx};
        %EC
        freqBand = [5 30];
        ccepEvent.components.early.info.exists = true(1);
        ccepEvent.components.early.info.startSec = 1/fs;
        ccepEvent.components.early.info.endSec = 0.1;
        ccepEvent.components.early.info.durationSec = 0.1;
        ccepEvent.components.early.info.nrWaves = getComponentNrWaves(ccepEvent.signal, fs, freqBand, ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);
        ccepEvent.components.early.info.spectralPeak = fftSpectralPeak(ccepEvent.signal, fs, freqBand,ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);

        %LC
        freqBand = [1 5];
        ccepEvent.components.late.info.exists = true(1);
        ccepEvent.components.late.info.startSec = 0.1;
        ccepEvent.components.late.info.endSec = 1.0;
        ccepEvent.components.late.info.durationSec = 0.9;
        ccepEvent.components.early.info.nrWaves = getComponentNrWaves(ccepEvent.signal, fs, freqBand, ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);
        ccepEvent.components.early.info.spectralPeak = fftSpectralPeak(ccepEvent.signal, fs, freqBand,ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);

        %PC
        freqBand = [1 30];
        ccepEvent.components.post.info.exists = true(1);
        ccepEvent.components.post.info.startSec = 1.0;
        ccepEvent.components.post.info.endSec = 3.0;
        if length(ccepEvent.signal)/fs < ccepEvent.components.post.info.endSec
            ccepEvent.components.post.info.endSec = length(ccepEvent.signal)/fs;
        end
        ccepEvent.components.post.info.durationSec = ccepEvent.components.post.info.endSec - ccepEvent.components.post.info.startSec;        
        ccepEvent.components.early.info.nrWaves = getComponentNrWaves(ccepEvent.signal, fs, freqBand, ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);
        ccepEvent.components.early.info.spectralPeak = fftSpectralPeak(ccepEvent.signal, fs, freqBand,ccepEvent.components.early.info.startSec, ccepEvent.components.early.info.endSec);

        ccepEventsToAnalyze{respIdx} = ccepEvent;
    end    
end

function nrWaves = getComponentNrWaves(signal, fs, freqBand, minLatencySec, maxLatencySec)

    blSignal = signal(end-(2*fs):end);
    thAmp = median(blSignal) + 2*std(blSignal);
    
    %Samples over Threshold
    posSamples = (signal >= thAmp);
    
   % are there enough consecutive positive samples?
    minNrConsecPos = (((1/freqBand(2))/2)/5)*fs;
    peakStart = 0;
    peakEnd = 0;
    for i = 1:length(posSamples)
        if peakStart == 0
            if posSamples(i) > 0
                peakStart = i;
                peakEnd = i;
            end
        else
            if posSamples(i) > 0
                peakEnd = i;
            else
                peakLength = peakEnd - peakStart + 1;
                if peakLength < minNrConsecPos
                    posSamples(peakStart:peakEnd) = 0;
                end
                peakStart = 0;
            end
        end
    end
    componentDetected = sum(posSamples) >= minNrConsecPos;

    nrWaves = 0;
    if componentDetected > 0
        sl = length(posSamples);
        posSamplesIndices = find(posSamples, sl, 'first');
        %find the gaps distance in samples
        posSamplesDistances = diff(posSamplesIndices);
        posSamplesStartIndices = posSamplesIndices(2:end);
        posSamplesEndIndices = posSamplesIndices(1:end-1);
        %find the gaps between waves
        minGapDist = ((1/freqBand(2))/8)*fs;
        waveStartSamples = cat(2, posSamplesIndices(1), posSamplesStartIndices(posSamplesDistances > minGapDist));
        waveEndSamples = cat(2, posSamplesEndIndices(posSamplesDistances > minGapDist), posSamplesIndices(end));
        waveMiddleSamples = waveStartSamples + (waveEndSamples - waveStartSamples)/2.0;
        %delete Waves with onset after the time boundary
        minSamplesLatency = int32(minLatencySec*fs);
        maxSamplesLatency = int32(maxLatencySec*fs);
        deleteWaves = (waveMiddleSamples < minSamplesLatency) | (waveMiddleSamples > maxSamplesLatency);
        waveStartSamples(deleteWaves) = [];
        nrWaves = length(waveStartSamples);
    end
end

function spectralPeakFreq = fftSpectralPeak(signal, fs, band, minLatencySec, maxLatencySec)
    startSample = minLatencySec*fs;
    endSample = maxLatencySec*fs;
    if startSample == 0
        startSample  = 1;
    end
    if endSample > length(signal)
        endSample  = length(signal);
    end

    signal = signal-mean(signal);
    signal = signal + abs(min(signal));
    signal = signal(startSample:endSample);
    
    lpad = 10*fs;
    xdft = fft(signal, lpad);
    xdft = xdft(1:lpad/2+1);            % Because the signal is real-valued, use only the positive frequencies from the DFT to estimate the amplitude
    xdft = xdft/length(signal);         % Scale the DFT by the length of the input signal
    xdft(2:end-1) = 2*xdft(2:end-1);    % multiply all frequencies except 0 and the Nyquist by 2
    xdft = real(xdft);
    freq = 0:fs/lpad:fs/2;
    
    bandSelect = (freq >= band(1) & freq <= band(2));
    xdft = xdft.*bandSelect;
    [maxVal maxIdx] = max(xdft);
    spectralPeakFreq = freq(maxIdx);
    spectralPeakPow = xdft(maxIdx)*xdft(maxIdx);
end