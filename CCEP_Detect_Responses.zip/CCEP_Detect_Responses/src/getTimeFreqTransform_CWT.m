function ccepEventsToAnalyze = getTimeFreqTransform_CWT(samplingRate, ccepEventsToAnalyze, plotCCEP_DetectionsOK, plotsDir)
    fs = samplingRate; 
    
    allResponsesSignal = [];
    allResponsesEvIdx = [];
    for respIdx = 1:size(ccepEventsToAnalyze,1)%149, 162
        ccepEvent = ccepEventsToAnalyze{respIdx};
        responseSignal = ccepEvent.signal;
        evIdx = ccepEvent.eventIdx;
        respLength = length(responseSignal);
        allResponsesSignal = cat(2, allResponsesSignal, responseSignal);
        allResponsesEvIdx = cat(2, allResponsesEvIdx, zeros(1, respLength)+evIdx);
    end
    
    %Transform
    nrCycles = 2;
    freqA = 0.25;
    freqB = 30;
    freqDelta = 0.25;%0.2;
    
    [frq wvltOut] = convCWT(fs, nrCycles, freqA, freqB, freqDelta, allResponsesSignal);
    %wvltOut = wvltOut.*wvltOut;
    
    plotOK = 0;
    for respIdx = 1:size(ccepEventsToAnalyze,1)%149, 162
        evIdx = ccepEventsToAnalyze{respIdx}.eventIdx;
        selVec = allResponsesEvIdx == evIdx;
        evPow = wvltOut(:, selVec);
        ccepEventsToAnalyze{respIdx}.cwt.freq = frq;
        ccepEventsToAnalyze{respIdx}.cwt.pow = evPow;
        
        if plotOK > 0
            signal = ccepEventsToAnalyze{respIdx}.signal;
            time = (0:length(signal)-1)/fs;

            subplot(2,1,1)
            plot(time, signal);
            xlim([min(time) max(time)]);

            subplot(2,1,2)
            contour(time, frq, evPow, 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
            title('Wavelet Power Spectrum')
            %colorbar
            xlabel('Time (s)')
            ylabel('Frequency (Hz)')
            set(gca,'yscale','log')
            set(gcf,'Colormap',jet)
            set(gca,'XLim',[min(time) max(time)], 'YLim',[min(frq) max(frq)],'XGrid','On', 'YGrid','On')
            close();
        end
    end
end