function ccepEventsDetectedComponents = detectCCEP_ComponentsMP(threshold, samplingRate, ccepEventsToAnalyze, responsesDictionary, baselineName, plotCCEP_DetectionsOK, plotsDir)
    fs = samplingRate;  

    %Filter
    order = 32;%same as baseline calculated with average channel signals
    filterDelay = order/2;
    h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
    
    nrECDetects = 0;
    nrLCDetects = 0;
    nrPCDetects = 0;

    
    parfor respIdx = 1:size(ccepEventsToAnalyze,1) %parfor
        ccepEvent = ccepEventsToAnalyze{respIdx};
        
        %add thsi entry to the structure
        ccepEvent.components.early.info = initializeComponent();
        ccepEvent.components.late.info = initializeComponent();
        ccepEvent.components.post.info = initializeComponent();

        responseSignal = ccepEventsToAnalyze{respIdx}.signal;
        evIdx = ccepEventsToAnalyze{respIdx}.eventIdx;
        stimChannName = ccepEventsToAnalyze{respIdx}.stimMontageName;
        responseChannName = ccepEventsToAnalyze{respIdx}.responseChannel;

        filtResponse = filter(h, 1, flip(responseSignal));
        filtResponse = filter(h, 1, flip(filtResponse));
        filtResponse(1:filterDelay) = filtResponse(filterDelay+1);
        filtResponse(end-filterDelay:end) = filtResponse(end-filterDelay-1);
        responseSignal = filtResponse;
        
        if strcmp(baselineName, 'allChannAvgBL')
            baseline = ccepEvent.baseline;
        elseif strcmp(baselineName, 'lastSecBL')
            blSignal = responseSignal(end-(1*fs):end);
            baseline = {responseChannName, mean(blSignal), median(blSignal), std(blSignal)};
        end

        mpResultPos = ccepEvent.mpResult{1};
        mpResultNeg = ccepEvent.mpResult{2};
        
        polStr = 'NormPolarity';
        mpResult = mpResultPos;
        if mpResultNeg.maxCorrel > mpResultPos.maxCorrel
            mpResult = mpResultNeg;
            responseSignal = responseSignal*-1;
            polStr = 'InvertPolarity';
        end
        ccepEvent.mpResult = mpResult;
        
        thStdDevEC = threshold;
        thStdDevLC = threshold;
        thStdDevPC = threshold;

        ecEvent = initializeComponent();
        minLatencySec = 0; maxLatencySec = 0.1; thAmpEC = baseline{3} + thStdDevEC*baseline{4};
        ecEvent = detectComponent(responseSignal, fs, thAmpEC, ecEvent, [5 30], responsesDictionary, mpResult, minLatencySec, maxLatencySec, 1);
        
        lcEvent = initializeComponent();
        minLatencySec = 0.1;
        if ecEvent.endSec > minLatencySec
            minLatencySec = ecEvent.endSec;
        end
        maxLatencySec = 1; thAmpLC = baseline{3} + thStdDevLC*baseline{4};
        lcEvent = detectComponent(responseSignal, fs, thAmpLC, lcEvent, [1 5], responsesDictionary, mpResult, minLatencySec, maxLatencySec, 2);

        pcEvent = initializeComponent();
        minLatencySec = 1; 
        if lcEvent.endSec > minLatencySec
            minLatencySec = lcEvent.endSec;
        end
        maxLatencySec = 3; thAmpPC = baseline{3} + thStdDevPC*baseline{4};
        pcEvent = detectComponent(responseSignal, fs, thAmpPC, pcEvent, [1 30], responsesDictionary, mpResult, minLatencySec, maxLatencySec, 3);

        %save to struct
        ccepEvent.components.early.info = ecEvent;
        ccepEvent.components.late.info = lcEvent;
        ccepEvent.components.post.info = pcEvent;

        nrECDetects = nrECDetects + ccepEvent.components.early.info.exists;
        nrLCDetects = nrLCDetects + ccepEvent.components.late.info.exists;
        nrPCDetects = nrPCDetects + ccepEvent.components.post.info.exists;
        
        %plotCCEP_DetectionsOK = (ecEvent.exists == 1 && lcEvent.exists == 1);

        if plotCCEP_DetectionsOK
            fig = figure(respIdx);
            time = (0:length(responseSignal)-1)/fs;
            
            atom = responsesDictionary{mpResult.atomIdx, 1};
            atom = rescale(atom, min(responseSignal), max(responseSignal));
            atomLength = length(atom);
            atomPlotTime = time(mpResult.sampleShift+1:mpResult.sampleShift+atomLength);

            subplot(5,1,5)
            plot(time, responseSignal, 'k'); hold on;
            xlim([min(time) max(time)]);

            subplot(5,1,1:4)
            plot(time, responseSignal, 'k'); hold on;
            ap = plot(atomPlotTime, atom, 'Color', 'g', 'LineWidth', 5); hold on;
            ap.Color(4) = 0.3;
            baseMean = baseline{3};
            hline(baseMean, 'y', 'BaselineAvg');
            hline(thAmpEC, 'm', 'Th');

            respIdx
            if ecEvent.exists == 1
                ecTime = time(ceil(ecEvent.startSec*fs):floor(ecEvent.endSec*fs));
                ecSignal = responseSignal(ceil(ecEvent.startSec*fs):floor(ecEvent.endSec*fs));
                plot(ecTime, ecSignal, 'r');

                ecString = {'Early Component'...
                            strcat('Nr.Waves:', num2str(ecEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(ecEvent.spectralPeak), 'Hz')...
                            strcat('Latency:', num2str(ecEvent.startSec), 's')...
                            strcat('Duration:', num2str(ecEvent.durationSec), 's')};
                eca=annotation('textbox', [0.8, 0.8, 0.1, 0.11], 'String', ecString,'FitBoxToText','on', 'BackgroundColor', 'w');
                eca.Color = 'r';
            end
            if lcEvent.exists == 1
                lcTime = time(ceil(lcEvent.startSec*fs):floor(lcEvent.endSec*fs));
                lcSignal = responseSignal(ceil(lcEvent.startSec*fs):floor(lcEvent.endSec*fs));
                plot(lcTime, lcSignal, 'b');
                lcString = {'Late Component'...
                            strcat('Nr.Waves:', num2str(lcEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(lcEvent.spectralPeak))...
                            strcat('Latency:', num2str(lcEvent.startSec))...
                            strcat('Duration:', num2str(lcEvent.durationSec))};
                lca=annotation('textbox', [0.8, 0.7, 0.1, 0.11], 'String', lcString,'FitBoxToText','on', 'BackgroundColor', 'w');
                lca.Color = 'b';
            end
            if pcEvent.exists == 1
                pcTime = time(ceil(pcEvent.startSec*fs):floor(pcEvent.endSec*fs));
                pcSignal = responseSignal(ceil(pcEvent.startSec*fs):floor(pcEvent.endSec*fs));
                plot(pcTime, pcSignal, 'Color',[1 0.412 0.161]);
                pcString = {'Post Component'...
                            strcat('Nr.Waves:', num2str(pcEvent.nrWaves))...
                            strcat('SpectralPeak:', num2str(pcEvent.spectralPeak))...
                            strcat('Latency:', num2str(pcEvent.startSec))...
                            strcat('Duration:', num2str(pcEvent.durationSec))};
                pca=annotation('textbox', [0.8, 0.6, 0.1, 0.11], 'String', pcString,'FitBoxToText','on', 'BackgroundColor', 'w');
                pca.Color = [1 0.412 0.161];
            end
            vline((0.1), 'g', '0.1s');
            vline((1), 'g', '1s');

            title({polStr, strcat('Stimulation:', stimChannName, '\_\_\_ Response:', responseChannName)})
            xlim([min(time) max(time)]);

            set(gcf, 'Position', get(0, 'Screensize'));
            channPlotDir = strcat(plotsDir, 'DetectedComponents\', responseChannName, '\');
            mkdir(channPlotDir)
            figOneFileName = strcat(channPlotDir, num2str(respIdx), '_Response_', responseChannName, 'Stim_', stimChannName);
            savefig(fig, figOneFileName, 'compact');
            hgexport(fig, figOneFileName, hgexport('factorystyle'), 'Format', 'jpeg');

            close;
        end
        ccepEventsToAnalyze{respIdx} = ccepEvent;
    end
    ccepEventsDetectedComponents = ccepEventsToAnalyze;
    [threshold nrECDetects nrLCDetects nrPCDetects]
end

function component = initializeComponent()
    component.exists = 0;
    component.nrWaves = 0;
    component.spectralPeak = 0;    
    component.startSec = 0;
    component.endSec = 0;
    component.durationSec = 0;        
end

function cccepCpmnt = detectComponent(signal, fs, thAmp, cccepCpmnt, freqBand, responsesDictionary, mpResult, minLatencySec, maxLatencySec, eventType)    
           
    ecAmpLength = responsesDictionary{mpResult.atomIdx, 2};
    lcAmpLength = responsesDictionary{mpResult.atomIdx, 3};
    samplesShift = mpResult.sampleShift;
    spaceLength = responsesDictionary{mpResult.atomIdx, 4};

    if eventType == 1
        eventExists = ecAmpLength(1) > 0 && mpResult.maxCorrel > 0.6;
        eventStartSec = (1 + samplesShift)/fs;
        eventDurationSec = ecAmpLength(2)/fs;
        eventFreq = 1/(eventDurationSec*2);
        selSignalSS = eventStartSec*fs;
        selSignalSE = selSignalSS + eventDurationSec*fs;
    elseif eventType == 2
        eventExists = lcAmpLength(1) > 0 && mpResult.maxCorrel > 0.6;
        eventStartSec = (samplesShift + ecAmpLength(2) + spaceLength + 1)/fs;
        eventDurationSec = lcAmpLength(2)/fs;
        eventFreq = 1/(eventDurationSec/0.75);
        selSignalSS = eventStartSec*fs;
        selSignalSE = selSignalSS + eventDurationSec*fs;
    elseif eventType == 3
        eventExists = 1;
        eventStartSec = (samplesShift + ecAmpLength(2) + spaceLength + lcAmpLength(2) + 1)/fs;
        eventDurationSec = length(signal)/fs - eventStartSec;
        selSignalSS = eventStartSec*fs;
        selSignalSE = selSignalSS + eventDurationSec*fs;
        if selSignalSS == 0
            selSignalSS = 1;
        end
        if selSignalSE > length(signal)
            selSignalSE = length(signal);
        end
        selSignal = signal(selSignalSS:selSignalSE);    
        eventFreq = fftSpectralPeak(selSignal, fs, freqBand);
        eventFreq = eventFreq.f;
        %eventFreq = getSpectralPeak(selSignal, fs, freqBand, minLatencySec, maxLatencySec);
    end
       
    if selSignalSS == 0
        selSignalSS = 1;
    end
    if selSignalSE > length(signal)
        selSignalSE = length(signal);
    end
    
    if eventExists > 0
        selSignal = signal(selSignalSS:selSignalSE);
        %Samples over Threshold
        posSamples = (selSignal >= thAmp);
       % are there enough consecutive positive samples?
        minNrConsecPos = (((1/freqBand(2))/2)/5)*fs;
        peakStart = 0;
        peakEnd = 0;
        for i = 1:length(posSamples)
            if peakStart == 0
                if posSamples(i) > 0
                    peakStart = i;
                    peakEnd = i;
                end
            else
                if posSamples(i) > 0
                    peakEnd = i;
                else
                    peakLength = peakEnd - peakStart + 1;
                    if peakLength < minNrConsecPos
                        posSamples(peakStart:peakEnd) = 0;
                    end
                    peakStart = 0;
                end
            end
        end
        componentDetected = sum(posSamples) >= minNrConsecPos;

        if componentDetected > 0
            waves = getComponentWaves(selSignal, posSamples, fs, freqBand, 0, 60);
            cccepCpmnt.exists = eventExists;    
            cccepCpmnt.nrWaves = waves.nr;
            cccepCpmnt.spectralPeak = eventFreq;    
            cccepCpmnt.startSec = eventStartSec;
            cccepCpmnt.endSec = eventStartSec + eventDurationSec;

            if cccepCpmnt.startSec < minLatencySec
                cccepCpmnt.startSec = minLatencySec;
            end
            if cccepCpmnt.startSec > maxLatencySec
                cccepCpmnt.startSec = maxLatencySec;
            end

            cccepCpmnt.durationSec = cccepCpmnt.endSec-cccepCpmnt.startSec;
        end
    end
    
end

%Get waves start, end and max samples based on the threshold
function waves = getComponentWaves(signal, posSamples, fs, freqBand, minLatencySec, maxLatencySec)
    sl = length(posSamples);
    posSamplesIndices = find(posSamples, sl, 'first');

    %find the gaps distance in samples
    posSamplesDistances = diff(posSamplesIndices);
    posSamplesStartIndices = posSamplesIndices(2:end);
    posSamplesEndIndices = posSamplesIndices(1:end-1);


    %find the gaps between waves
    minGapDist = ((1/freqBand(2))/8)*fs;
    waveStartSamples = cat(2, posSamplesIndices(1), posSamplesStartIndices(posSamplesDistances > minGapDist));
    waveEndSamples = cat(2, posSamplesEndIndices(posSamplesDistances > minGapDist), posSamplesIndices(end));
    waveMiddleSamples = waveStartSamples + (waveEndSamples - waveStartSamples)/2.0;
    
    %delete Waves with onset after the time boundary
    minSamplesLatency = int32(minLatencySec*fs);
    maxSamplesLatency = int32(maxLatencySec*fs);
    deleteWaves = (waveMiddleSamples < minSamplesLatency) | (waveMiddleSamples > maxSamplesLatency);
    waveStartSamples(deleteWaves) = [];
    waveEndSamples(deleteWaves) = [];
    
    nrWaves = length(waveStartSamples);
    
    firstWaveMaxIdx = 0;
    firstWaveStartIdx = 0;
    firstWaveEndIdx = 0;
    lastWaveMaxIdx = 0;
    lastWaveStartIdx = 0;
    lastWaveEndIdx = 0; 
                    
    if nrWaves > 0
        firstWaveStartIdx = waveStartSamples(1);
        firstWaveEndIdx = waveEndSamples(1);
        fwsignal = signal(firstWaveStartIdx:firstWaveEndIdx);
        [maxVAl maxIdx] = max(fwsignal);
        firstWaveMaxIdx = firstWaveStartIdx + maxIdx;
        
        lastWaveStartIdx = waveStartSamples(end);
        lastWaveEndIdx = waveEndSamples(end);
        lwsignal = signal(lastWaveStartIdx:lastWaveEndIdx);
        [maxVAl maxIdx] = max(lwsignal);
        lastWaveMaxIdx = lastWaveStartIdx + maxIdx;
        if lastWaveMaxIdx == maxSamplesLatency
            stop = 1;
        end
    end
    
    waves.nr = nrWaves;
    waves.sp = 0;
    waves.first = cat(2, double([firstWaveMaxIdx firstWaveStartIdx, firstWaveEndIdx]), 0);
    waves.last = cat(2, double([lastWaveMaxIdx lastWaveStartIdx, lastWaveEndIdx]), 0);
end

function spectralPeak = fftSpectralPeak(signal, fs, band)
    signal = signal-mean(signal);
    signal = signal + abs(min(signal));
    lpad = 10*fs;
    xdft = fft(signal, lpad);
    xdft = xdft(1:lpad/2+1);            % Because the signal is real-valued, use only the positive frequencies from the DFT to estimate the amplitude
    xdft = xdft/length(signal);         % Scale the DFT by the length of the input signal
    xdft(2:end-1) = 2*xdft(2:end-1);    % multiply all frequencies except 0 and the Nyquist by 2
    xdft = real(xdft);
    freq = 0:fs/lpad:fs/2;
    
    bandSelect = (freq >= band(1) & freq <= band(2));
    xdft = xdft.*bandSelect;
    [maxVal maxIdx] = max(xdft);
    spectralPeak.f = freq(maxIdx);
    spectralPeak.p = xdft(maxIdx)*xdft(maxIdx);
end

function spectralPeak = getSpectralPeak(signal, fs, freqBand, minLatencySec, maxLatencySec)

    signal = signal-mean(signal);
    signal = signal + abs(min(signal));
    
    startSample = minLatencySec*fs;
    endSample = maxLatencySec*fs;
    if startSample == 0
        startSample  = 1;
    end
    if endSample > length(signal)
        endSample  = length(signal);
    end

    y = signal(startSample:endSample);
    y = cat(2, y, zeros(1,fs*10));

    Fs = fs;                % Sampling frequency                    
    T = 1/Fs;               % Sampling period       
    L = length(y);          % Length of signal
    t = (0:L-1)*T;          % Time vector

    Yfft = fft(y);
    P2 = abs(Yfft/L);
    P1 = P2(1:L/2+1);
    P1(2:end-1) = 2*P1(2:end-1);

    f = Fs*(0:(L/2))/L;
    
%     subplot(2,1,1)
%     plot(t, y);
%     title('Signal')
%     xlabel('t (milliseconds)')
%     subplot(2,1,2)
%     plot(f,P1) 
%     title('Single-Sided Amplitude Spectrum of Signal')
%     xlabel('f (Hz)')
%     ylabel('|P1(f)|')

    P1(f < freqBand(1)) = 0;
    P1(f > freqBand(2)) = 0;

    [maxVal, maxIdx] = max(P1);
    spectralPeak = f(maxIdx);

end
