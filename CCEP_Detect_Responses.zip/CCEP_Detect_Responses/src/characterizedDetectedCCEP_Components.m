function ccepEventsToAnalyze = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir)

    %ccepEventsToAnalyze = getHFO_CWT(samplingRate, ccepEventsToAnalyze, plotCCEP_DetectionsOK, plotsDir);

    %Filter
    order = 128;
    filterDelay = order/2;
    h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
    fs = samplingRate;
    
    %iterate through all the CCEPs
    %parfor respIdx = 1:size(ccepEventsToAnalyze,1)
    parfor respIdx = 1:size(ccepEventsToAnalyze,1)
        ccepEvent = ccepEventsToAnalyze{respIdx};
        response = ccepEventsToAnalyze{respIdx}.signal;
        evIdx = ccepEventsToAnalyze{respIdx}.eventIdx;
        globalStartSample = ccepEventsToAnalyze{respIdx}.globalStartSample;
        stimChannName = ccepEventsToAnalyze{respIdx}.stimMontageName;
        responseChannName = ccepEventsToAnalyze{respIdx}.responseChannel;
        
        filtResponse = filter(h, 1, flip(response));
        filtResponse = filter(h, 1, flip(filtResponse));
        filtResponse(1:filterDelay) = filtResponse(filterDelay+1);
        filtResponse(end-filterDelay:end) = filtResponse(end-filterDelay-1);
        
        baseline = [];
        if strcmp(baselineName, 'allChannAvgBL')
            baseline = ccepEvent.baseline;
        elseif strcmp(baselineName, 'lastTwoSecBL')
            blSignal = response(end-(2*fs):end);
            baseline = {responseChannName, mean(blSignal), median(blSignal), std(blSignal)};
        end

        ccepEvent = characterizeComponents(evIdx, response, filtResponse, baseline, samplingRate, globalStartSample, ccepEvent);
        
        plotCCEP_DetectionsOK = 0;
        if plotCCEP_DetectionsOK
            plotCCEP_Analysis(evIdx, response, filtResponse, samplingRate, globalStartSample, ccepEventsToAnalyze{respIdx}, stimChannName, responseChannName, baseline, plotsDir);
        end
        ccepEvent.cwt = [];
        ccepEventsToAnalyze{respIdx} = ccepEvent;
    end
end

function ccepEvent = characterizeComponents(evIdx, response, filtResponse, baseline, samplingRate, globalStartSample, ccepEvent)

        evIdx; 
        fs = samplingRate;
        time = (globalStartSample:globalStartSample+length(response)-1)/samplingRate;
        ecExists = ccepEvent.components.early.info.exists;
        lcExists = ccepEvent.components.late.info.exists;
        pcExists = ccepEvent.components.post.info.exists;
    
        %get spectrogram        
        %get spectrogram
        [minPossFreq,maxPossFreq] = cwtfreqbounds(length(response), fs);
        [cfs,frq, coi] = cwt(flip(response),'amor', fs, 'FrequencyLimits',[80 500]);
        absCFS = abs(flip(cfs,2));
        waveletPowSpectrum.freqBins = frq;
        waveletPowSpectrum.spectrum = absCFS;
        %waveletPowSpectrum.freqBins = ccepEvent.cwt.freq;
        %waveletPowSpectrum.spectrum = ccepEvent.cwt.pow;       
        
        %Early Component
        eventType = 1;
        ccepEvent.components.early = characterizeComponent(filtResponse, baseline, fs, eventType, ccepEvent.components.early);
        ccepEvent.components.early = characterizeBiomarkersInComponent(response, fs, eventType, ccepEvent.components.early, ccepEvent.detectedBiomarkers, waveletPowSpectrum);

        %Late Component
        eventType = 2;
        ccepEvent.components.late = characterizeComponent(filtResponse, baseline, fs, eventType, ccepEvent.components.late);
        ccepEvent.components.late = characterizeBiomarkersInComponent(response, fs, eventType, ccepEvent.components.late, ccepEvent.detectedBiomarkers, waveletPowSpectrum);

        %Post Component
        eventType = 3;
        ccepEvent.components.post = characterizeComponent(filtResponse, baseline, fs, eventType, ccepEvent.components.post);
        ccepEvent.components.post = characterizeBiomarkersInComponent(response, fs, eventType, ccepEvent.components.post, ccepEvent.detectedBiomarkers, waveletPowSpectrum);
end

function component = characterizeComponent(filteredSignal, baseline, fs, eventType, component)

    sampleStart = 1;
    sampleEnd = 0.1 * fs;
    
    if eventType == 2
        sampleStart = 0.1*fs;
        sampleEnd = 1*fs;
    elseif eventType == 3
        sampleStart = 1*fs;
        sampleEnd = 3*fs;
    end
        
    if component.info.exists > 0
        sampleStart = component.info.startSec*fs;
        sampleEnd = component.info.endSec*fs;
    end
    sampleStart = int64(sampleStart);
    sampleEnd = int64(sampleEnd);
    
    %avoid out of bounds indexing
    if(sampleEnd > length(filteredSignal))
        sampleEnd = length(filteredSignal);
    end
    
    segment = filteredSignal(sampleStart:sampleEnd);
    segmentLength = length(segment);
    segmentLengthSec = length(segment)/fs;
    

    component.features.maxAmplitude = 0;
    component.features.sumAmplitude = 0;
    component.features.amplVariance = 0;
    component.features.avgLL = 0;
    component.features.avgPower = 0;
    component.features.sumPower = 0;
    component.features.peaksPerSec = 0;
    component.features.mobility = 0;
    component.features.complexity = 0;
    
    
    component.features.maxAmplitude = abs(max(segment)-min(segment));
    component.features.sumAmplitude = sum(abs(segment-mean(filteredSignal)));
    component.features.amplVariance = var(segment);
    component.features.avgLL = sum(abs(diff(segment,1)));
    component.features.avgPower = sum(segment.*segment)/segmentLength;
    component.features.sumPower = sum(segment.*segment);

    nrPeaks = 0;
    %if segmentLength > 25
        for i = 4:segmentLength-3
            peakPreTestNeg = sum((segment(i-3:i-1)) < (segment(i)));
            peakPostTestNeg = sum((segment(i+1:i+3)) < (segment(i)));
            peakPreTestPos = sum((segment(i-3:i-1)) > (segment(i)));
            peakPostTestPos = sum((segment(i+1:i+3)) > (segment(i)));
            if(peakPreTestNeg >= 3 && peakPostTestNeg >= 3) || (peakPreTestPos >= 3 && peakPostTestPos >= 3)
                nrPeaks = nrPeaks+1;
            end
        end
    %end
    component.features.peaksPerSec = double(nrPeaks) / component.info.durationSec;
    component.features.mobility = sqrt(var(diff(segment,1))/component.features.amplVariance);
    component.features.complexity = sqrt( var(diff(segment,2)) / var(diff(segment,1)) ) / component.features.mobility;
    
end

function component = characterizeBiomarkersInComponent(signal, fs, eventType, component, allDetections, waveletPowSpectrum)

    sampleStart = 1;
    sampleEnd = 0.1 * fs;
    if eventType == 2
        sampleStart = 0.1*fs;
        sampleEnd = 1*fs;
    elseif eventType == 3
        sampleStart = 1*fs;
        sampleEnd = 3.5*fs;
    end
        
    if component.info.exists > 0
        sampleStart = component.info.startSec*fs;
        sampleEnd = component.info.endSec*fs;
    end
    sampleStart = int64(sampleStart);
    sampleEnd = int64(sampleEnd);
    componentDurationSec = double(sampleEnd-sampleStart+1)/fs;
    
    selectedIndices = [];
    if size(allDetections, 2) > 0
        selectedIndices = (allDetections(2,:) >= sampleStart) & (allDetections(3,:) <= sampleEnd);    
    end
    detectionWithinComponent = allDetections(:, selectedIndices);
    
    component.biomarkers.Ripples = [];
    component.biomarkers.FR = [];
    component.biomarkers.HFO = [];
    component.biomarkers.iesRipples = [];
    component.biomarkers.iesFR = [];
    component.biomarkers.iesHFO = [];
    component.biomarkers.isolRipples = [];
    component.biomarkers.isolFR = [];
    component.biomarkers.isolHFO = [];
    component.biomarkers.IES = [];

    eoiMarks = [1];
    component.biomarkers.Ripples = characterizeBiomarkerSignal(signal, fs, component.biomarkers.Ripples, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [2];
    component.biomarkers.FR = characterizeBiomarkerSignal(signal, fs, component.biomarkers.FR, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [1, 2];
    component.biomarkers.HFO = characterizeBiomarkerSignal(signal, fs, component.biomarkers.HFO, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);

    
    eoiMarks = [4];
    component.biomarkers.iesRipples = characterizeBiomarkerSignal(signal, fs, component.biomarkers.iesRipples, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [5];
    component.biomarkers.iesFR = characterizeBiomarkerSignal(signal, fs, component.biomarkers.iesFR, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [4, 5];
    component.biomarkers.iesHFO = characterizeBiomarkerSignal(signal, fs, component.biomarkers.iesHFO, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);

    
    eoiMarks = [6];
    component.biomarkers.isolRipples = characterizeBiomarkerSignal(signal, fs, component.biomarkers.isolRipples, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [7];
    component.biomarkers.isolFR = characterizeBiomarkerSignal(signal, fs, component.biomarkers.isolFR, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);
    eoiMarks = [6, 7];
    component.biomarkers.isolHFO = characterizeBiomarkerSignal(signal, fs, component.biomarkers.isolHFO, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);

    eoiMarks = [3];
    component.biomarkers.IES = characterizeBiomarkerSignal(signal, fs, component.biomarkers.IES, detectionWithinComponent, eoiMarks, waveletPowSpectrum, componentDurationSec);

end

function biomarker = characterizeBiomarkerSignal(signal, samplingRate, biomarker, detectionWithinComponent, eoiMarks, waveletPowSpectrum, segmentDurationSec)
    
    detections = [];
    nrAllDetections = size(detectionWithinComponent, 2);
    if nrAllDetections > 0
        for msi = 1:length(eoiMarks)
            detections = cat(2, detections, detectionWithinComponent(:, detectionWithinComponent(1, :) == eoiMarks(msi)) );
        end
    end

    biomarker.rate = 0;
    biomarker.avgDuration = 0;
    
    biomarker.avgMaxAmpl = 0;
    biomarker.avgSumAmpl = 0;
    biomarker.avgVariance = 0;
    biomarker.avgBPLL = 0;
    biomarker.avgPower = 0;
    biomarker.avgSumPower = 0;
    biomarker.avgPeaks = 0;
    biomarker.mobility = 0;
    biomarker.complexity = 0;
    
    biomarker.avgZeroCrossPerEOI = 0;
    biomarker.avgPBRatio = 0;
    biomarker.avgSpectCentroid = 0;
    biomarker.avgSpectPeak = 0;
    
    nrDetections = size(detections, 2);
    if nrDetections > 0
                
        biomarker.rate = nrDetections / segmentDurationSec;
        biomarker.avgDuration = mean((detections(3,:)+1) - detections(2,:)) / samplingRate;
        
        for di = 1:nrDetections
            label = detections(1, di);
            startSample = int64(detections(2,di));
            endSample = int64(detections(3,di));
            
            %Filter the signal to calculate features
            order = 128;
            h = fir1(order, [80/(samplingRate/2) 250/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
            if label == 2 || label == 5 || label == 7
                h = fir1(order, [250/(samplingRate/2) 500/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'                
            end
            filteredHFO_Signal = filter(h, 1, flip(signal));
            filteredHFO_Signal = flip(filteredHFO_Signal);

            biomarker = characterizeDetectedEvent(filteredHFO_Signal, startSample, endSample, waveletPowSpectrum, samplingRate, biomarker);
        end
        
        biomarker.avgMaxAmpl = biomarker.avgMaxAmpl  / nrDetections;
        biomarker.avgSumAmpl = biomarker.avgSumAmpl / nrDetections;
        biomarker.avgVariance = biomarker.avgVariance  / nrDetections;
        biomarker.avgBPLL = biomarker.avgBPLL  / nrDetections;
        biomarker.avgPower = biomarker.avgPower  / nrDetections;
        biomarker.avgSumPower = biomarker.avgSumPower  / nrDetections;
        biomarker.avgPeaks = biomarker.avgPeaks  / nrDetections;
        biomarker.mobility = biomarker.mobility  / nrDetections;
        biomarker.complexity = biomarker.complexity  / nrDetections;

        biomarker.avgZeroCrossPerEOI = biomarker.avgZeroCrossPerEOI  / nrDetections;
        biomarker.avgPBRatio = biomarker.avgPBRatio  / nrDetections;
        biomarker.avgSpectCentroid = biomarker.avgSpectCentroid  / nrDetections;
        biomarker.avgSpectPeak = biomarker.avgSpectPeak  / nrDetections;

    end
end

function biomarker = characterizeDetectedEvent(filteredSignal, startSample, endSample, waveletPowSpectrum, samplingRate, biomarker)
    detectionSignal = filteredSignal(startSample : endSample);
    segmentLength = length(detectionSignal);
    signalDurationSec = double(segmentLength)/double(samplingRate);
        
    biomarker.avgMaxAmpl = biomarker.avgMaxAmpl + abs(max(detectionSignal)-min(detectionSignal));
    biomarker.avgSumAmpl = biomarker.avgSumAmpl + sum(abs(detectionSignal-mean(filteredSignal)));
    eoiVariance = var(detectionSignal);
    biomarker.avgVariance = biomarker.avgVariance + eoiVariance;
    biomarker.avgBPLL = biomarker.avgBPLL + sum(abs(diff(detectionSignal,1)));
    biomarker.avgPower = biomarker.avgPower + sum(detectionSignal.*detectionSignal)/segmentLength;
    biomarker.avgSumPower = biomarker.avgSumPower + sum(detectionSignal.*detectionSignal);

    nrPeaks = 0;
    peakBufferLength = 3;
    if segmentLength > peakBufferLength+1
        for i = peakBufferLength+1:segmentLength-peakBufferLength
            peakPreTestNeg = sum((detectionSignal(i-peakBufferLength:i-1)) < (detectionSignal(i)));
            peakPostTestNeg = sum((detectionSignal(i+1:i+peakBufferLength)) < (detectionSignal(i)));
            peakPreTestPos = sum((detectionSignal(i-peakBufferLength:i-1)) > (detectionSignal(i)));
            peakPostTestPos = sum((detectionSignal(i+1:i+peakBufferLength)) > (detectionSignal(i)));
            if(peakPreTestNeg >= peakBufferLength && peakPostTestNeg >= peakBufferLength) || (peakPreTestPos >= peakBufferLength && peakPostTestPos >= peakBufferLength)
                nrPeaks = nrPeaks+1;
            end
        end
    end
        
    biomarker.avgPeaks = biomarker.avgPeaks + (double(nrPeaks) / signalDurationSec);
    
    eoiMobility = (sqrt(var(diff(detectionSignal,1))/eoiVariance));
    eoiComplexity = sqrt( var(diff(detectionSignal,2)) / var(diff(detectionSignal,1)) ) / eoiMobility;
    biomarker.mobility = biomarker.mobility + eoiMobility;
    biomarker.complexity = biomarker.complexity + eoiComplexity;
    
    nrZC = 0;
    zeroRef = mean(filteredSignal);
    zcBuffer = 2;
    for i = 1:segmentLength
        preS = i-zcBuffer;
        preE = i-1;
        postS = i;
        postE = i+zcBuffer-1;

        if preS >= 1 && preE <= segmentLength && postS >= 1 && postE <= segmentLength

            zcPreTestDown = sum(detectionSignal(preS:preE) < zeroRef);
            zcPostTestDown = sum(detectionSignal(postS:postE) > zeroRef);
            zcPreTestUp = sum(detectionSignal(preS:preE) > zeroRef);
            zcPostTestUp = sum(detectionSignal(postS:postE) < zeroRef);
            if(zcPreTestDown >= zcBuffer && zcPostTestDown >= zcBuffer) || (zcPreTestUp >= zcBuffer && zcPostTestUp >= zcBuffer)
                nrZC = nrZC+1;
            end
        end
    end
    
    biomarker.avgZeroCrossPerEOI = biomarker.avgZeroCrossPerEOI + (double(nrZC) / signalDurationSec);
        
    waveletSpectrum = waveletPowSpectrum.spectrum(:, startSample:endSample);
    
    selectIdx = (waveletPowSpectrum.freqBins >=80 & waveletPowSpectrum.freqBins <= 250); 
    rippleBandPower = sum(waveletSpectrum(selectIdx, :) .* waveletSpectrum(selectIdx, :),'all');
    selectIdx = (waveletPowSpectrum.freqBins > 250 & waveletPowSpectrum.freqBins <= 500); 
    frBandPower = sum(waveletSpectrum(selectIdx, :) .* waveletSpectrum(selectIdx, :),'all');
    biomarker.avgPBRatio = biomarker.avgPBRatio + frBandPower / rippleBandPower;

    biomarker.avgSpectCentroid = biomarker.avgSpectCentroid + mean(sum(waveletSpectrum(:, :).*waveletPowSpectrum.freqBins,1) ./ sum(waveletSpectrum(:, :),1));

    avgMaxPowFreq = 0;
    for i = 1:size(waveletSpectrum, 2)
        [power, freqIdx] = max(waveletSpectrum(:, i));        
		avgMaxPowFreq = avgMaxPowFreq+waveletPowSpectrum.freqBins(freqIdx);
    end
	avgMaxPowFreq = avgMaxPowFreq/size(waveletSpectrum, 2);
    biomarker.avgSpectPeak = biomarker.avgSpectPeak + avgMaxPowFreq;
         
end

function ccepEventsToAnalyze = getHFO_CWT(samplingRate, ccepEventsToAnalyze, plotCCEP_DetectionsOK, plotsDir)
    fs = samplingRate; 
    
    allResponsesSignal = [];
    allResponsesEvIdx = [];
    for respIdx = 1:size(ccepEventsToAnalyze,1)%149, 162
        ccepEvent = ccepEventsToAnalyze{respIdx};
        responseSignal = ccepEvent.signal;
        evIdx = ccepEvent.eventIdx;
        respLength = length(responseSignal);
        allResponsesSignal = cat(2, allResponsesSignal, responseSignal);
        allResponsesEvIdx = cat(2, allResponsesEvIdx, zeros(1, respLength)+evIdx);
    end
    
    %get spectrogram
    [minPossFreq,maxPossFreq] = cwtfreqbounds(length(allResponsesSignal), fs);
    [cfs,frq, coi] = cwt(allResponsesSignal,'amor', fs, 'FrequencyLimits',[80 500]);
    absCFS = abs(cfs);
        
    plotOK = 0;
    for respIdx = 1:size(ccepEventsToAnalyze,1)%149, 162
        evIdx = ccepEventsToAnalyze{respIdx}.eventIdx;
        selVec = allResponsesEvIdx == evIdx;
        evPow = absCFS(:, selVec);
        ccepEventsToAnalyze{respIdx}.cwt.freq = frq;
        ccepEventsToAnalyze{respIdx}.cwt.pow = evPow;
        
%         if plotOK > 0
%             signal = ccepEventsToAnalyze{respIdx}.signal;
%             time = (0:length(signal)-1)/fs;
% 
%             subplot(2,1,1)
%             plot(time, signal);
%             xlim([min(time) max(time)]);
% 
%             subplot(2,1,2)
%             contour(time, frq, evPow, 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
%             title('Wavelet Power Spectrum')
%             %colorbar
%             xlabel('Time (s)')
%             ylabel('Frequency (Hz)')
%             set(gca,'yscale','log')
%             set(gcf,'Colormap',jet)
%             set(gca,'XLim',[min(time) max(time)], 'YLim',[min(frq) max(frq)],'XGrid','On', 'YGrid','On')
%             close();
%         end
    end
end

function plotCCEP_Analysis(evIdx, response, filtResponse, samplingRate, globalStartSample, ccepEvent, stimChannName, responseChannName, baseline, plotsDir)
    evIdx   
    fs = samplingRate;
    time = (globalStartSample:globalStartSample+length(response)-1)/samplingRate;
    ecExists = ccepEvent.components.early.info.exists;
    lcExists = ccepEvent.components.late.info.exists;

    plotOk = 1;(ecExists || lcExists);
    if plotOk
        figID = figure(evIdx);
        %Plot signal
        subplot(3,1,1)
        rescaledRaw = rescale(response, min(filtResponse), max(filtResponse));
        %yyaxis left
        plot(time, rescaledRaw, 'b'); hold on;%[17 17 17]
        fsPlot = plot(time, filtResponse, 'k', 'LineWidth', 3); hold on;
        fsPlot.Color(4) = 0.6;
        ylim([min(filtResponse) max(filtResponse)])
        grid on
        grid minor

        %Plot segment marked as ER
        if ecExists
            erSampleStart = int64((ccepEvent.components.early.info.startSec)*fs);
            erSampleEnd = erSampleStart + int64((ccepEvent.components.early.info.durationSec)*fs);
            erSegment = filtResponse(erSampleStart:erSampleEnd);
            erSegmentTime = time(erSampleStart:erSampleEnd);
            erPlot = plot(erSegmentTime, erSegment,  'Color', [0.9294 0.6902 0.1294], 'LineWidth', 3); hold on;
            erPlot.Color(4) = 1;0.2;  
        end
        %Plot segment marked as LR
        if lcExists
            lrSampleStart = int64((ccepEvent.components.late.info.startSec)*fs);
            lrSampleEnd = lrSampleStart + int64((ccepEvent.components.late.info.durationSec)*fs);        
            lrSegment = filtResponse(lrSampleStart:lrSampleEnd);
            lrSegmentTime = time(lrSampleStart:lrSampleEnd);
            lrPlot = plot(lrSegmentTime, lrSegment,  'Color', [0.4902 0.1804 0.5608], 'LineWidth', 3); hold on;
            lrPlot.Color(4) = 1;0.2;
        end

        %Plot 100ms and 1s
        vline(time(1) + 0.1, 'g', '100ms');
        vline(time(1) + 1, 'g', '1s');

        xlim([min(time) max(time)])
        detectTitleStr = {...
        strcat('D\_', num2str(evIdx), '\_Response\_', responseChannName, '\_\_Stim\_', stimChannName),...
        strcat(' EC_{start}:', num2str(ccepEvent.components.early.info.startSec), 'ms', ' EC_{duration}:',num2str(ccepEvent.components.early.info.durationSec), 'ms'),...
        strcat(' LC_{start}:', num2str(ccepEvent.components.late.info.startSec), 'ms', ' LC_{duration}:',num2str(ccepEvent.components.late.info.durationSec), 'ms')};
        if ecExists && lcExists
            detectTitleStr = {strcat('D\_', num2str(evIdx), '\_Response\_', responseChannName, '\_\_Stim\_', stimChannName),...
            strcat(' EC_{start}:', num2str(ccepEvent.components.early.info.startSec), 'ms', ' EC_{duration}:',num2str(ccepEvent.components.early.info.durationSec), 'ms'),...
            strcat(' LC_{start}:', num2str(ccepEvent.components.late.info.startSec), 'ms', ' LC_{duration}:',num2str(ccepEvent.components.late.info.durationSec), 'ms')};
            legend('Raw Signal', 'Filtered Signal (0.5 - 45 Hz)', 'Detected EC', 'Detected LC', 'FontSize', 16);
        elseif ecExists
            detectTitleStr = {strcat('D\_', num2str(evIdx), '\_Response\_', responseChannName, '\_\_Stim\_', stimChannName),...
            strcat(' EC_{start}:', num2str(ccepEvent.components.early.info.startSec), 'ms', ' EC_{duration}:',num2str(ccepEvent.components.early.info.durationSec), 'ms')};
            legend('Raw Signal', 'Filtered Signal (0.5 - 45 Hz)', 'Detected EC', 'FontSize', 16);
        elseif lcExists
            detectTitleStr = {strcat('D\_', num2str(evIdx), '\_Response\_', responseChannName, '\_\_Stim\_', stimChannName),...
            strcat(' LC_{start}:', num2str(ccepEvent.components.late.info.startSec), 'ms', ' LC_{duration}:',num2str(ccepEvent.components.late.info.durationSec), 'ms')};
            legend('Raw Signal', 'Filtered Signal (0.5 - 45 Hz)', 'Detected LC', 'FontSize', 16);
        else
            detectTitleStr = {strcat('D\_', num2str(evIdx), '\_Response\_', responseChannName, '\_\_Stim\_', stimChannName)};
            legend('Raw Signal', 'Filtered Signal (0.5 - 45 Hz)', 'FontSize', 16);                                
        end
        title(detectTitleStr, 'FontSize', 14)

        grid on

        %%%%%%%%%%%%%%%%%Plot HFO Detection%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        subplot(3,1,2)
        hfoSignal = response;
        order = 128;
        filterDelay = order/2;
        h = fir1(order/2, [80/(samplingRate/2) 500/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
        filteredHFO_Signal = filter(h, 1, flip(hfoSignal));
        filteredHFO_Signal = filter(h, 1, flip(filteredHFO_Signal));
        filteredHFO_Signal(1:filterDelay) = filteredHFO_Signal(filterDelay+1);
        filteredHFO_Signal(end-filterDelay:end) = filteredHFO_Signal(end-filterDelay-1);
        legendString = {'Band-Passed (80-500 Hz)'};
        hfoPlot = plot(time, filteredHFO_Signal,'k','LineWidth',0.01); hold on;
        hfoPlot.Color(4) = 0.2;
        nrFR = 0;
        nrRipples = 0;
        nrIES = 0;
        for detIdx = 1:size(ccepEvent.detectedBiomarkers, 2)
            Ripple = ccepEvent.detectedBiomarkers(1, detIdx) == 1;
            if Ripple
                startSample = ccepEvent.detectedBiomarkers(2, detIdx);
                endSample = ccepEvent.detectedBiomarkers(3, detIdx);
                ripplePlot = plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'b','LineWidth',0.01); hold on;
                ripplePlot.Color(4) = 0.4;
                nrRipples = nrRipples+1;
            end
            FR = ccepEvent.detectedBiomarkers(1, detIdx) == 2;
            if FR
                startSample = ccepEvent.detectedBiomarkers(2, detIdx);
                endSample = ccepEvent.detectedBiomarkers(3, detIdx);
                frPlot = plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'r','LineWidth',0.01); hold on;
                frPlot.Color(4) = 0.4;
                nrFR = nrFR+1;
            end
            IES = ccepEvent.detectedBiomarkers(1, detIdx) == 3;
            if IES
                startSample = ccepEvent.detectedBiomarkers(2, detIdx);
                endSample = ccepEvent.detectedBiomarkers(3, detIdx);
                iesPlot = plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'g','LineWidth',0.01); hold on;
                iesPlot.Color(4) = 0.25;
                nrIES = nrIES+1;
            end
        end
        axis tight
        xlabel('Time (s)')
        ylabel('Amplitude')
        xlim([min(time) max(time)])
        title('all EOI', 'FontSize',20)
        legendObjects = [];
        legendObjects = cat(1, legendObjects, hfoPlot(1));
        if nrRipples > 0
            legendString = cat(1, legendString, strcat('Ripple Detections (', num2str(nrRipples), ')'));
            legendObjects = cat(1, legendObjects, ripplePlot(1));
        end
        if nrFR > 0
            legendString = cat(1, legendString, strcat('FR Detections (', num2str(nrFR), ')'));
            legendObjects = cat(1, legendObjects, frPlot(1));
        end
        if nrIES > 0
            legendString = cat(1, legendString, strcat('IES Detections (', num2str(nrIES), ')'));
            legendObjects = cat(1, legendObjects, iesPlot(1));
        end
        legend(legendObjects, legendString,'FontSize',16)
        grid on

    %%%%%%%%%%%%%%%%%Plot HFO Range Wavelet Time-Freqeuncy Decomposition%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        subplot(3,1,3)
        %nrStdDevs = 15;
        %upperFence = ccepEvent.waveletNorm_Max_Min_Avg_Std(3) + nrStdDevs*ccepEvent.waveletNorm_Max_Min_Avg_Std(4);
        %lowerFence = ccepEvent.waveletNorm_Max_Min_Avg_Std(3) - nrStdDevs*ccepEvent.waveletNorm_Max_Min_Avg_Std(4);
        upperFence = ccepEvent.waveletNorm_Max_Min_Avg_Std(1);
        lowerFence = ccepEvent.waveletNorm_Max_Min_Avg_Std(2);

        [minPossFreq,maxPossFreq] = cwtfreqbounds(length(hfoSignal), samplingRate);
        [cfs,frq, coi] = cwt(hfoSignal,'amor', samplingRate, 'FrequencyLimits',[60 600]);
        normCFS = abs(cfs);
        normCFS(normCFS > upperFence) = upperFence;
        normCFS(normCFS < lowerFence) = lowerFence;

        contour(time,frq,normCFS, 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
        %caxis([lowerFence, upperFence])
        title('Wavelet Power Spectrum')
        colorbar('Location','east', 'AxisLocation', 'in', 'Box', 'on', 'Color', 'w', 'FontSize', 12, 'FontWeight', 'bold');
        xlabel('Time (s)')
        ylabel('Frequency (Hz)')
        %set(gca,'yscale','log')
        set(gcf,'Colormap',jet)
        set(gca,'XLim',[min(time) max(time)], 'YLim',[min(frq) max(frq)],'XGrid','On', 'YGrid','On')

        set(gcf, 'Position', get(0, 'Screensize'));

        mkdir(strcat(plotsDir, 'ResponseDetection\'))
        channPlotDir = strcat(plotsDir, 'ResponseDetection\', responseChannName, '\');
        mkdir(channPlotDir)
        figExpFN = strcat(channPlotDir, 'D_', num2str(evIdx), '_Response_', responseChannName, '_Stim_', stimChannName);
        hgexport(gcf, figExpFN, hgexport('factorystyle'), 'Format', 'jpeg');
        figFN = strcat(channPlotDir, 'D_', num2str(evIdx), '_Response_', responseChannName, '_Stim_', stimChannName, '.fig');
        savefig(figID, figFN,'compact');
        close();
    end
end