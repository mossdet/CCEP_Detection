function [reducedDictionary] = getCCEP_ResponsesDictionary(samplingFrequency, plotsDir)

    atomsPlotDir = strcat(plotsDir, 'AtomsMP\');
    mkdir(atomsPlotDir)


    fs = samplingFrequency;

    %get early responses
    erAtoms = {};
    erAmpLength = [];
    erIdx = 1;
    for earlyRespAmpl = 0:2
        freqDomain = 5:2.5:30;
        if earlyRespAmpl == 0
            freqDomain = [5:5:30];
        end
        for earlyRespFreq = freqDomain
            t = (1/fs):(1/fs):(1/(earlyRespFreq))*0.5;
            y = earlyRespAmpl*sin(2*pi*earlyRespFreq*t);
            erAtoms{erIdx} = y;
            erAmpLength = cat(1, erAmpLength, [earlyRespAmpl length(y)]);
            erIdx = erIdx+1;
        end
    end

    %get late responses
    lrAtoms = {};
    lrAmpLength = [];
    lrIdx = 1;
    %lateRespAmplSet = 0;
    %lateRespAmplSet = cat(2, lateRespAmplSet, 10:0.1:20);
    for lateRespAmpl = 0:2
        freqDomain = 1:5;
        for lateRespFreq = freqDomain
            t = (1/fs):(1/fs):(1/(lateRespFreq))* 0.75;%(11/16);
            y = (lateRespAmpl*sin(2*pi*lateRespFreq*t));
            lrAtoms{lrIdx} = y;
            lrAmpLength = cat(1, lrAmpLength, [lateRespAmpl length(y)]);
            lrIdx = lrIdx+1;
        end
    end

    spaceAtoms = {};
    spaceLineIdx = 1;
    %spaceLineAtoms{spaceLineIdx} = [];
    for spaceDuration = 0:0.05:0.2
        nrSpaceLineSamps = spaceDuration*fs;
        spaceAtoms{spaceLineIdx} = transpose(zeros(int32(nrSpaceLineSamps), 1));
        spaceLineIdx = spaceLineIdx+1;
    end
    
    %get all responses
    nER_Atoms = size(erAtoms, 2);
    nLR_Atoms = size(lrAtoms, 2);
    nrSpaceAtoms = size(spaceAtoms, 2);

    dictionary = {};
    dicIdx = 1;
    
    allZerosDurations = [];

    for eri = 1:nER_Atoms
        for lri = 1:nLR_Atoms
            for spi = 1:nrSpaceAtoms
                erAtomComponent = erAtoms{eri};
                spaceAtomComponent = spaceAtoms{spi};
                lrAtomComponent = lrAtoms{lri};

                y = cat(2, erAtomComponent, spaceAtomComponent, lrAtomComponent);

                lcOnset = (length(erAtomComponent) + length(spaceAtomComponent))/fs;
                if (lcOnset < 0.1)
                    continue;
                end
                
                if (erAmpLength(eri, 1) > 0) || (lrAmpLength(lri, 1) > 0) 
                    stop = true;
                end

                dictionary{dicIdx, 1} = y;
                dictionary{dicIdx, 2} = erAmpLength(eri, :);
                dictionary{dicIdx, 3} = lrAmpLength(lri, :);
                dictionary{dicIdx, 4} = length(spaceAtomComponent);
                dicIdx = dicIdx+1;

                plotAtoms = 0;
                if plotAtoms == 1
                    lengthER = length(erAtomComponent);
                    lengthLR = length(lrAtomComponent);
                    lengthSpace = length(spaceAtomComponent);
                    totalCumAtomLength = lengthER + lengthSpace + lengthLR;

                    %y = avgJunctionPoint(y, erAtomComponent, lrAtomComponent);

                    subplot(4,1,1)
                    plot(erAtoms{eri}, 'LineWidth',5)
                    title('EC from Atom','FontSize',22)
                    xlim([0 totalCumAtomLength])

                    subplot(4,1,2)
                    plot(lrAtoms{lri}, 'LineWidth',5)
                    title('LC from Atom','FontSize',22)
                    xlim([0 totalCumAtomLength])

                    subplot(4,1,3)
                    plot(spaceAtomComponent, 'LineWidth',5)
                    title('Sapce component from Atom','FontSize',22)
                    xlim([0 totalCumAtomLength])

                    subplot(4,1,4)
                    plot(y, 'LineWidth',5)
                    title({strcat('EC-Duration:', num2str(erAmpLength(eri, 2)),' s,', 'Space-Duration:', num2str(length(spaceAtomComponent)/fs),' s, LC-Duration:', num2str(lrAmpLength(lri, 2)), ' s'), strcat('EC-Ampl.:', num2str(erAmpLength(eri, 1)),',    LC-Ampl.:', num2str(lrAmpLength(lri, 1)))},'FontSize',22)
                    xlim([0 totalCumAtomLength])

                    set(gcf, 'Position', get(0, 'Screensize'));
                    figOneFileName = strcat('ER_Dur_', num2str(lengthER),'Hz_LR_Dur_', num2str(lengthLR), 'Hz_ER_Ampl_', num2str(erAmpLength(eri, 1)), 'LR_Ampl_', num2str(lrAmpLength(lri, 1)), '_SpaceDuration_', num2str(lengthSpace));
                    figOneFileName = strcat(atomsPlotDir, figOneFileName);
                    %savefig(f1, figOneFileName{1});
                    hgexport(gcf, figOneFileName, hgexport('factorystyle'), 'Format', 'jpeg');
                    close();
                end
            end
        end    
    end
    
    nrAtoms = size(dictionary, 1)
    atomsDelete = zeros(nrAtoms, 1);
    for fai = 1:nrAtoms-1
        firstAtom = dictionary{fai, 1};
        for sai = fai+1:nrAtoms
            if atomsDelete(sai)
                continue;
            end
            secondAtom = dictionary{sai, 1};
            atomsEqual = isequal(firstAtom, secondAtom);
            if atomsEqual
                atomsDelete(sai) = 1;
            end
        end
    end
    reducedDictionary = {};
    redDictIdx = 1;
    for atIdx = 1:nrAtoms
        if atomsDelete(atIdx)
            continue;
        end
        reducedDictionary{redDictIdx, 1} = dictionary{atIdx, 1};
        reducedDictionary{redDictIdx, 2} = dictionary{atIdx, 2};
        reducedDictionary{redDictIdx, 3} = dictionary{atIdx, 3};
        reducedDictionary{redDictIdx, 4} = dictionary{atIdx, 4};
        redDictIdx = redDictIdx+1;
    end
    nrEditedAtoms = size(reducedDictionary, 1);
    
    responsesDictionary = reducedDictionary;
    save('..\MP_Dictionary\Saved_Dictionary.mat', 'responsesDictionary');
end

function y = avgJunctionPoint(signal, erAtomComponent, lrAtomComponent)
    lengthER = length(erAtomComponent);
    lengthLR = length(lrAtomComponent);

    erfq = erAtomComponent(1:lengthER/4);
    lrfq = lrAtomComponent(1:lengthLR/4);
    intERFQ = interp1(1:length(erfq), erfq, 1:length(lrfq), 'spline');
    newLRFQ = (intERFQ + lrfq)/2;
    

    erlq = erAtomComponent(end-lengthER/4:end);
    lrlq = lrAtomComponent(end-lengthLR/4:end);
    intERFQ = interp1(1:length(erlq), erlq, 1:length(lrlq), 'spline');
    newERLQ = (lrlq + intERFQ) / 2; 
    
    newSignal = cat(2, erAtomComponent(1:end-lengthER/4), newERLQ, newLRFQ, lrAtomComponent(lengthLR/4:end));
    
    plot(signal); hold on;
    plot(newSignal); hold on;

end