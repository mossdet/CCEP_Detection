function getCCEP_DataDetection(patientName, recordName, patientRecordPath, selectedEEG_Labels, baselines, samplingRate, plotCCEP_DetectionsOK, plotsDir)

    nrChannels = length(selectedEEG_Labels);
    baselines = {'lastSecBL'; 'allChannAvgBL'};
    thresholds = [0:1:9; 0:0.25:2.5];

    %Detect fixed times only once since it doesn't use a threshold
    %nor a baseline
    parfor chIdx = 1:nrChannels %parfor
        channName = selectedEEG_Labels{chIdx};      
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL', patientName, recordName, channName);
        %Fixed Times
        detectorType = 'FixedTimes';
        ccepEventsToAnalyzeFT = detectCCEP_ComponentsFixedTimes(samplingRate, ccepEventsToAnalyze, [], plotCCEP_DetectionsOK, plotsDir);
        ccepEventsToAnalyzeFT = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeFT, 'None', plotCCEP_DetectionsOK, plotsDir);
        saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL_', detectorType, '_', 'None', '_Th_', num2str(0));
        saveProcessedData(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeFT);
    end

    %Vertex
    detectorType = 'Vertex';
    for bi = 1:length(baselines)
        baselineName = baselines{bi};
        for thi = 1:length(thresholds)
            threshold = thresholds(thi);
            parfor chIdx = 1:nrChannels %parfor
                channName = selectedEEG_Labels{chIdx};
                ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL', patientName, recordName, channName);
                ccepEventsToAnalyzeVertex = detectCCEP_ComponentsVertices(threshold, samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir);
                ccepEventsToAnalyzeVertex = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeVertex, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveProcessedData(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeVertex);
            end
        end
    end
    
    %Wavelet
    detectorType = 'Wavelet';
    for chIdx = 1:nrChannels
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL', patientName, recordName, channName);
        ccepEventsToAnalyze = getTimeFreqTransform_CWT(samplingRate, ccepEventsToAnalyze, plotCCEP_DetectionsOK, plotsDir);
        for bi = 1:length(baselines)
            baselineName = baselines{bi};
            for thi = 1:length(thresholds)
                threshold = thresholds(thi);
                ccepEventsToAnalyzeCWT = detectCCEP_ComponentsCWT(threshold, samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir);
                ccepEventsToAnalyzeCWT = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeCWT, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveProcessedData(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeCWT);
            end
        end
    end

    %Matching Pursuit
    detectorType = 'MP';
    load('..\MP_Dictionary\Saved_Dictionary.mat','responsesDictionary');
    for chIdx = 1:nrChannels
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL', patientName, recordName, channName);
        ccepEventsToAnalyze = getCCEP_MP_Result(samplingRate, ccepEventsToAnalyze, responsesDictionary);
        ccepEventsToAnalyze = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyze, '', plotCCEP_DetectionsOK, plotsDir);
        for bi = 1:length(baselines)
            baselineName = baselines{bi};
            for thi = 1:length(thresholds)
                threshold = thresholds(thi);
                ccepEventsToAnalyzeMP = detectCCEP_ComponentsMP(threshold, samplingRate, ccepEventsToAnalyze, responsesDictionary, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveProcessedData(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeMP);    
            end
        end
    end
end

function saveProcessedData(type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    mkdir(patientRecordPath);
    save(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function ccepEventsToAnalyze = loadProcessedData(type, patientName, recordName, channName)
    ccepEventsToAnalyze = [];
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    load(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end
