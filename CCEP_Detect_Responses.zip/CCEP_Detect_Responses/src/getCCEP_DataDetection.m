function getCCEP_DataDetection(patientName, recordName, patientRecordPath, selectedEEG_Labels, baselines, samplingRate, plotCCEP_DetectionsOK, plotsDir)

    nrChannels = length(selectedEEG_Labels);
    baselines = {'lastSecBL'};%{'allChannAvgBL'; 'lastSecBL'};
    thresholds = [2.5 5 7.5 10];

    %Detect fixed times only once since it doesn't use a threshold
    %nor a baseline
    parfor chIdx = 1:nrChannels %parfor
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = [];        
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName, ccepEventsToAnalyze);
        %Fixed Times
        detectorType = 'FixedTimes';
        ccepEventsToAnalyzeFT = detectCCEP_ComponentsFixedTimes(samplingRate, ccepEventsToAnalyze, [], plotCCEP_DetectionsOK, plotsDir);
        ccepEventsToAnalyzeFT = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeFT, 'None', plotCCEP_DetectionsOK, plotsDir);
        saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', 'None', '_Th_', num2str(0));
        saveChannelEvents(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeFT);
    end

    %Vertex
    detectorType = 'Vertex';
    for bi = 1:length(baselines)
        baselineName = baselines{bi};
        for thi = 1:length(thresholds)
            threshold = thresholds(thi);
            parfor chIdx = 1:nrChannels %parfor
                channName = selectedEEG_Labels{chIdx};
                ccepEventsToAnalyze = [];        
                ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName, ccepEventsToAnalyze);
                ccepEventsToAnalyzeVertex = detectCCEP_ComponentsVertices(threshold, samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir);
                ccepEventsToAnalyzeVertex = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeVertex, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveChannelEvents(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeVertex);
            end
        end
    end
    
    %Wavelet
    detectorType = 'Wavelet';
    for chIdx = 1:nrChannels
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = [];        
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName, ccepEventsToAnalyze);
        ccepEventsToAnalyze = getTimeFreqTransform_CWT(samplingRate, ccepEventsToAnalyze, plotCCEP_DetectionsOK, plotsDir);
        for bi = 1:length(baselines)
            baselineName = baselines{bi};
            for thi = 1:length(thresholds)
                threshold = thresholds(thi);
                ccepEventsToAnalyzeCWT = detectCCEP_ComponentsCWT(threshold, samplingRate, ccepEventsToAnalyze, baselineName, plotCCEP_DetectionsOK, plotsDir);
                ccepEventsToAnalyzeCWT = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyzeCWT, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveChannelEvents(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeCWT);
            end
        end
    end

    %Matching Pursuit
    detectorType = 'MP';
    load('..\MP_Dictionary\Saved_Dictionary.mat','responsesDictionary');
    for chIdx = 1:nrChannels
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = [];        
        ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName, ccepEventsToAnalyze);
        ccepEventsToAnalyze = getCCEP_MP_Result(samplingRate, ccepEventsToAnalyze, responsesDictionary);
        ccepEventsToAnalyze = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyze, '', plotCCEP_DetectionsOK, plotsDir);
        for bi = 1:length(baselines)
            baselineName = baselines{bi};
            for thi = 1:length(thresholds)
                threshold = thresholds(thi);
                ccepEventsToAnalyzeMP = detectCCEP_ComponentsMP(threshold, samplingRate, ccepEventsToAnalyze, responsesDictionary, baselineName, plotCCEP_DetectionsOK, plotsDir);
                saveType = strcat('CCEP_TRIALS_PLUS_HFO_IES_', detectorType, '_', baselineName, '_Th_', num2str(floor(threshold)));
                saveChannelEvents(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyzeMP);    
            end
        end
    end
end

function characterizeDetectedComponents(detectorType, threshold, baselineName, selectedEEG_Labels, patientName, recordName, samplingRate, baseline, plotCCEP_DetectionsOK, plotsDir)
    %Characterize CCEP Components and complete zones for non normalized
    %signal
    nrChannels = length(selectedEEG_Labels);
    parfor chIdx = 1:nrChannels
        chIdx
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = [];
        loadType = strcat('HFO_CCEP_FEATS_ZONES_', detectorType, '_', baselineName, '_Th_', num2str(threshold));
        ccepEventsToAnalyze = loadProcessedData(loadType, patientName, recordName, channName, ccepEventsToAnalyze);
        ccepEventsToAnalyze = characterizedDetectedCCEP_Components(samplingRate, ccepEventsToAnalyze, baseline, plotCCEP_DetectionsOK, plotsDir);
        saveType = strcat('HFO_CCEP_FEATS_ZONES_CHARACT_', detectorType, '_', baselineName, '_Th_', num2str(threshold));
        saveChannelEvents(detectorType, saveType, patientName, recordName, channName, ccepEventsToAnalyze);
    end
end

function saveChannelEvents(detectorType, type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('F:\CCEP_Data\CCEP_Detections\', detectorType, '\');
    mkdir(patientRecordPath);
    patientRecordPath = strcat(patientRecordPath, type, '\', patientName, '\', recordName, '\');
    mkdir(patientRecordPath);
    save(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function ccepEventsToAnalyze = loadProcessedData(type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('F:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    load(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end
function ccepEventsToAnalyze = loadChannelEvents(detectorType, type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('F:\CCEP_Data\CCEP_Detections\', detectorType, '\');
    patientRecordPath = strcat(patientRecordPath, '_',type, '\', patientName, '\', recordName, '\');
    load(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function deleteChannelEvents(type, patientName, recordName, channName)
    patientRecordPath = strcat('F:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    delete(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'));
end
