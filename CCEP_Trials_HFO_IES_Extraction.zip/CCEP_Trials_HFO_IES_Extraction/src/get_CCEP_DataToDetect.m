clc;
clear all;
close all;

patientsAndRecords = gePatientsAndRecords();
excludeChannels = {'C3', 'C4', 'Cz', 'F3', 'F4', 'F7', 'F8', 'Fp1', 'FP1', 'Fp2', 'FP2', 'Fz', 'FZ', 'O1', 'O2', 'P3', 'P4', 'Pz', 'T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'igger', 'ekg', 'EKG', 'EMG', 'emg', 'EOG','EOG_o', 'EOG_u', 'EOG_li', 'EOG_re'};
hfoDetectorFolder = 'D:\MATLAB\Projects\CCEP_Trials_HFO_IES_Extraction\MOSSDET_c\';

read_CCEP_Data(patientsAndRecords, excludeChannels, hfoDetectorFolder)


function read_CCEP_Data(patientsAndRecords, excludeChannels, hfoDetectorFolder)
    for patIdx = 1:size(patientsAndRecords,2)
        patientName = patientsAndRecords{patIdx}{1};
        badChannels = patientsAndRecords{patIdx}{4};
        whiteMatterChannels = readWhiteMatterChannels(patientName)';
        piChannels = getChannelsWithPI(patientName);
        badChannels = cleanChannelList(badChannels);
        whiteMatterChannels = cleanChannelList(whiteMatterChannels);
        piChannels = cleanChannelList(piChannels);

        for recIdx = 0:patientsAndRecords{patIdx}{3}
            suffix = strcat('_000', num2str(recIdx));
            if(recIdx > 9)
                suffix = strcat('_00', num2str(recIdx));
            end

            recordName = strcat(patientsAndRecords{patIdx}{2}, suffix);
            recordPath = strcat('F:\CCEP_Data\', patientsAndRecords{patIdx}{1}, '\CCEP_EEG\', patientsAndRecords{patIdx}{2}, suffix, '.vhdr')

            plotsDir = strcat('..\Plots\', patientName, '\', patientsAndRecords{patIdx}{1}, '_', patientsAndRecords{patIdx}{2}, suffix, '\');
            mkdir(plotsDir);

            cfg = [];
            cfg.dataset = recordPath;

            %read eeg data
            data_eeg        = ft_preprocessing(cfg);
            data_eeg.label = cleanChannelList(data_eeg.label);
            samplingRate = data_eeg.fsample;
            if samplingRate < 2000
                error('Sampling Rate insufficent for HFO detection');
            end

            % read marks
            cfg.trialdef.eventtype = 'Stimulus';
            cfg_ccep_trial = ft_definetrial(cfg);
            
            selectedEEG_Labels = selectChannelsToProcess(data_eeg.label, piChannels, excludeChannels, badChannels, whiteMatterChannels);

            getCCEP_Trials_HFO_IES(patientName, recordName, data_eeg, cfg_ccep_trial, selectedEEG_Labels, hfoDetectorFolder, plotsDir);
        end
    end
end

function channList = cleanChannelList(channList)
    channList= strrep(channList, '_', '');
    channList = strrep(channList, '-', '');
end

function whiteMatterChannels = readWhiteMatterChannels(patientName)
    zoiFileName = strcat('F:\CCEP_Data\', patientName, '\', patientName, '_CorticalChannels.txt');
    FID=fopen(zoiFileName);
    header = textscan(FID,'%s%s', 1, 'Delimiter','\t');
    corticChanns = textscan(FID, '%s%d', 'HeaderLines', 1, 'CollectOutput', 0);
    fclose(FID);
    whiteMatterChannels = corticChanns{1}(not(corticChanns{2}));
end

%Get channels with a defined propagation index
function channNamesPI = getChannelsWithPI(patientName)

    %Read the file
    seizurePropagationsFN = strcat('F:\CCEP_Data\', patientName, '\', patientName, '_Propagations.txt');
    piFile = tdfread(seizurePropagationsFN,'\t');
    szrData = struct2cell(piFile);
    dataLabels = szrData{1,1};

    %get and correct channel names
    channNamesPI = cell(size(szrData{1},1)-3,1);
    for i = 1:size(channNamesPI,1)
        channNamesPI{i} = dataLabels(i,:);
        channNamesPI{i} = strrep(channNamesPI{i},' ', '');
        channNamesPI{i} = strrep(channNamesPI{i},'\t', '');
    end   
end

function selectedEEG_Labels = selectChannelsToProcess(eegLabels, piChannels, excludeChannels, badChannels, whiteMatterChannels)

    %select channels to ignore
    nonPI_Channels = {};
    schi = 1;
    for chi = 1:length(eegLabels)
        chName = eegLabels{chi};
        if sum(strcmp(piChannels, chName)) == 0
            nonPI_Channels{schi} = chName;
            schi = schi+1;
        end
    end 
    ignoreChannels = cat(2, excludeChannels, badChannels, whiteMatterChannels, nonPI_Channels);

    %select channels to process
    selectedEEG_Labels = {};
    schi = 1;
    for chi = 1:length(eegLabels)
        chName = eegLabels{chi};
        if sum(strcmp(ignoreChannels, chName)) == 0
            selectedEEG_Labels{schi} = chName;
            schi = schi+1;
        end
    end 
end
function patientsAndRecords = gePatientsAndRecords()
    patientsAndRecords = {};
    pi = 1;
    patientsAndRecords{pi} = {'P013', 'ccep_20150924_2000', 4, {'_'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P016', 'CCEP_20151811Block1', 5, {'TR7', 'TR8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P018', 'ccep_20160203', 6, {'TAR7', 'TAR8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P023', 'CCEP_RUN2_20170223', 4, {'AR8', 'AR9', 'AR10'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P025', 'ccep_run20170321', 8, {'TAR8', 'TAR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P026', 'ccep_run20170518', 4, {'TOL10', 'TOL11'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P028', 'cceo_20170720_run1', 6, {'TAL7', 'TAL8'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P032', 'ccep_20171208_2', 7, {'PHL9', 'AR2'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P033', 'ccep_run20180227', 6, {'TSPR3', 'TSPR4'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P034', 'ccep_run20180319', 7, {'TML1', 'TML2', 'TML3', 'TML4'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P036', 'CCEP_20180904', 6, {'TAL10', 'TAR7', 'ECR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P037', 'CCEP_20181018', 3, {'IAL4', 'IAL5'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P038', 'ccep_run20181116', 3, {'_'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P039', 'ccep_run20181129', 4, {'FBR13', 'HAR11'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P040', 'ccep_run20190115', 6, {'HAR10', 'EL7'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P041', 'ccep_20190129', 4, {'ER9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P043', 'ccep_20190220', 4, {'FBR9'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P045', 'ccep_20190408', 4, {'AL9', 'AL10'}}; pi = pi+1;
    patientsAndRecords{pi} = {'P047', 'CCEP_Run1_20190724', 6, {'AL10', 'AL11'}}; pi = pi+1;
end