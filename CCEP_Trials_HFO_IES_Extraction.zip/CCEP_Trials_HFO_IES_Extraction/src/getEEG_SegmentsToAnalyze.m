function ccepEventsToAnalyze = getEEG_SegmentsToAnalyze(data_eeg, selectedEEG_Labels, stimEvents, patientName, recordName, signal, samplingRate, channName, plotTrialsSignals, plotsDir)
    fs = samplingRate;
    responseChannel = channName;
    responseChannel = erase(responseChannel,'_');
    responseChannel = erase(responseChannel,'-');
    nrEvents = size(stimEvents,1);

    ccepEventsToAnalyze = {};    
    for ei = 1:nrEvents
        ccepEvent = initializeCCEP_Event();
        ccepEventsToAnalyze = cat(1, ccepEventsToAnalyze, ccepEvent);
    end   
    
    for ei = 1:nrEvents
        %{globalEvIdx, stimStartSample, stimEndSample, trialEndSample, channOneStim, channTwoStim, stimMontageName, eventDuration}
        channOneStim = stimEvents{ei, 5};
        channTwoStim = stimEvents{ei, 6};
        stimMontageName = stimEvents{ei, 7};
        prevStimMontageName = [];
        nextStimMontageName = [];
        
        if ei > 1
            prevStimMontageName = stimEvents{ei-1, 7};
        end
        if ei < nrEvents
            nextStimMontageName = stimEvents{ei+1, 7};
        end
        if not((strcmp(responseChannel,channOneStim)) || (strcmp(responseChannel,channTwoStim)))
            
            if ~strcmp(stimMontageName,prevStimMontageName) || ~strcmp(stimMontageName,nextStimMontageName)
                continue;
            end
            %ignore those segments of teh channel being analyzed which are
            %within the time when teh channel was also the stimulus channel

            %stimPulseStart = int32(stimEvents{ei, 2})-(0.005*fs);                    %this sample is actually the end of stimulus artefact
            [maxVal maxSamp] = max(signal(int32(stimEvents{ei, 2}):int32(stimEvents{ei, 2})+(0.02*fs)));
            stimPulseStart = maxSamp + int32(stimEvents{ei, 2})-(0.005*fs);
            stimPulseEnd = stimPulseStart +  (0.02*fs);
            %get Stim End
%             [maxVal maxSamp] = max(signal(stimPulseStart:stimPulseStart+(0.02*fs)));
%             stimPulseEnd = int32(maxSamp+ stimPulseStart)+ (0.002*fs);                    %this sample is actually the end of stimulus artefact
            
            stimPulseSamplesDuration = stimPulseEnd - stimPulseStart + 1;
            stimulusTrialEnd = int32(stimEvents{ei, 4})-int32(0.1*fs);        %this sample is actually the end of stimulus artefact

            rewindTime = 0.05;
            rewindSamples = int32(rewindTime*samplingRate);
            if stimPulseStart-rewindSamples < 0
                rewindSamples = int32(stimPulseStart-1);
                rewindTime = rewindSamples/fs;
            end
           
            artfSignalDrift = (signal(stimPulseStart-rewindSamples:stimulusTrialEnd));

            artfSignal = (signal(stimPulseStart-rewindSamples:stimulusTrialEnd));
            artfTime = (0:length(artfSignal)-1)/samplingRate;
            
            interpolStartSample = rewindSamples - 1;
            interpolEndSample = interpolStartSample + stimPulseSamplesDuration + 1;
            noArtfSignal = cat(2,artfSignal(1:interpolStartSample), artfSignal(interpolEndSample:end));
            noArtfTime =   cat(2,artfTime(1:interpolStartSample), artfTime(interpolEndSample:end));

            %interpolSignal = spline(noArtfTime, noArtfSignal, artfTime);
            interpolSignal = artfSignal;
            interpolSignal(interpolStartSample:interpolEndSample) = artfSignal(interpolStartSample);
            trialInterpolSignal = cat(2, interpolSignal(interpolStartSample:interpolEndSample), artfSignal(interpolEndSample+1:end));
            trialInterpolTime = artfTime(interpolStartSample:end);

            %wholeTrialsignal = (signal(stimPulseStart:stimulusTrialEnd));
            %trialInterpolSignal(stimDurationSamples:end) = wholeTrialsignal;

            %remove drift
            p = polyfit(trialInterpolTime, trialInterpolSignal, 1);
            drift = polyval(p, trialInterpolTime);
            trialInterpolSignalNoDrift = trialInterpolSignal - drift;
            trialInterpolSignalNoDriftNoHum = fftBandStop(trialInterpolSignalNoDrift, fs, 48, 52);

            %drift angle
            a = (drift(end)-drift(1));
            b = length(drift);
            c = sqrt((a^2)+(b^2));
            aUnit = a/c;
            bUnit = b/c;
            cUnit = sqrt((aUnit^2)+(bUnit^2));
            driftAngle = rad2deg(asin(aUnit/cUnit));
            driftStr = strcat(num2str(driftAngle), char(176));
            
            if(driftAngle > 20)
                stop = 1;
            end
            
            if plotTrialsSignals > 0
                fig = figure(stimEvents{ei, 1})
                subplot(3,1,1)
                plot(artfTime, artfSignalDrift, 'Color', 'k', 'LineWidth', 1); legend('Raw Signal with Stim. Artefact and Drift');hold on;
                vline(rewindTime, 'r');
                vline(double(interpolStartSample)/fs, 'y', 'IPS');
                vline(double(interpolEndSample)/fs, 'y', 'IPE');
                vline(rewindTime + 0.1, 'g', '0.1s');
                vline(rewindTime + 1, 'g', '1s');
                xlim([0 max(artfTime)]);

        %                 subplot(4,1,2)
        %                 plot(artfTime, artfSignal, 'Color', 'k', 'LineWidth', 3); legend('Raw Signal with Stim. Artefact no Drift');
        %                 vline((0.1), 'r');
        %                 vline((0.2), 'g', '0.1s');
        %                 vline((1.1), 'g', '1s');
        %                 xlim([0 max(artfTime)]);

                subplot(4,1,2)
                plot(artfTime, interpolSignal, 'Color', 'k', 'LineWidth', 1); legend('Interpolation of whole signal minus Stim. Artefact');
                vline(rewindTime, 'r');
                vline(double(interpolStartSample)/fs, 'y', 'IPS');
                vline(double(interpolEndSample)/fs, 'y', 'IPE');
                vline(rewindTime + 0.1, 'g', '0.1s');
                vline(rewindTime + 1, 'g', '1s');
                xlim([0 max(artfTime)]);

                subplot(4,1,3)
                xlim([0 (length(trialInterpolSignal)-1)/samplingRate]);
                plot((0:length(trialInterpolSignal)-1)/samplingRate, trialInterpolSignal, 'Color', 'k', 'LineWidth', 1);hold on;
                p2 = plot((0:length(trialInterpolSignal)-1)/samplingRate, drift, 'Color', 'm', 'LineWidth', 2);hold on;
                p2.Color(4) = 0.5;
                ylim([min(trialInterpolSignal), max(trialInterpolSignal)]);
                xlim([0 (length(trialInterpolSignal)-1)/samplingRate]);
                vline(0, 'r');
                vline((0.1), 'g', '0.1s');
                vline((1), 'g', '1s');
                legend('Trial Analysis Signal, replace Stim. Artefact with interpolation', driftStr);

                subplot(4,1,4)
                interpolNoDriftTime = (0:length(trialInterpolSignalNoDriftNoHum)-1)/samplingRate;
                xlim([0 interpolNoDriftTime(end)]);
                col = 'k';
                if abs(driftAngle) > 25
                    col = 'c';
                end
                plot(interpolNoDriftTime, trialInterpolSignalNoDriftNoHum, 'Color', col, 'LineWidth', 0.1);hold on;
                ylim([min(trialInterpolSignalNoDriftNoHum), max(trialInterpolSignalNoDriftNoHum)]);
                xlim([0 (length(trialInterpolSignalNoDriftNoHum)-1)/samplingRate]);
                vline(0, 'r');
                vline((0.1), 'g', '0.1s');
                vline((1), 'g', '1s');

                ecSignal = trialInterpolSignalNoDriftNoHum((interpolNoDriftTime < 0.1));
                lcSignal = trialInterpolSignalNoDriftNoHum((interpolNoDriftTime>0.1) & (interpolNoDriftTime < 1));
                pcSignal = trialInterpolSignalNoDriftNoHum((interpolNoDriftTime>1));

                spectralPeakEC = fftSpectralPeak(ecSignal, fs);
                spectralPeakLC = fftSpectralPeak(lcSignal, fs);
                spectralPeakPC = fftSpectralPeak(pcSignal, fs);

                lind = length(trialInterpolSignalNoDriftNoHum);
                %baseline = abs(trialInterpolSignalNoDriftNoHum(lind-2*fs:end));
                baseline = trialInterpolSignalNoDriftNoHum;%(trialInterpolSignalNoDriftNoHum(1*fs:lind-0.1*fs));
                %baseline = (trialInterpolSignalNoDriftNoHum);
                blMean = median(baseline);
                thPower = blMean + 2*std(baseline);
                evSel = (trialInterpolSignalNoDriftNoHum >= thPower) & (interpolNoDriftTime < 1);
                eventsSignal = trialInterpolSignalNoDriftNoHum(evSel);
                eventsTime = interpolNoDriftTime(evSel);
                plot(eventsTime, eventsSignal, 'ro', 'MarkerSize', 1, 'MarkerEdgeColor','r', 'MarkerFaceColor', 'r')
                %hline(thPower, 'r', 'Threshold');
                hline(mean(trialInterpolSignalNoDriftNoHum), 'y', 'avg');

                legend('Trial Analysis Signal, no Stim.Artefact, no Drift',...
                    strcat('Detected Events, EC:', num2str(spectralPeakEC.f), 'Hz, ',...
                    'LC:', num2str(spectralPeakLC.f), 'Hz, ',...
                    'PC:', num2str(spectralPeakPC.f), 'Hz'));

                set(gcf, 'Position', get(0, 'Screensize'));

                channPlotDir = strcat(plotsDir, 'CCEP_Trials\', responseChannel, '\');
                mkdir(channPlotDir)
                figOneFileName = strcat(channPlotDir, num2str(stimEvents{ei, 1}), '_Response_', responseChannel, 'Stim_', stimMontageName);
                savefig(fig, figOneFileName, 'compact');
                hgexport(fig, figOneFileName, hgexport('factorystyle'), 'Format', 'jpeg');
                close();
            end

            if abs(driftAngle) > 10
                continue;
            end
                
            ccepEventsToAnalyze{ei}.patientName = patientName;
            ccepEventsToAnalyze{ei}.recordName = recordName;            
            ccepEventsToAnalyze{ei}.eventIdx = stimEvents{ei, 1};
            ccepEventsToAnalyze{ei}.globalStartSample = stimEvents{ei, 2};
            ccepEventsToAnalyze{ei}.signal = trialInterpolSignalNoDriftNoHum;
            ccepEventsToAnalyze{ei}.baseline = {};
            ccepEventsToAnalyze{ei}.driftAngle = driftAngle;
            ccepEventsToAnalyze{ei}.waveletNorm_Max_Min_Avg_Std = [0 0 0 0];
            ccepEventsToAnalyze{ei}.stimMontageName = stimMontageName;
            ccepEventsToAnalyze{ei}.responseChannel = responseChannel;
        end
    end
    
    %clean the events, remove those having same stimulation and response channe
    clean_ccepEventsToAnalyze = [];
    for ei = 1:nrEvents
        if not(isempty(ccepEventsToAnalyze{ei}.patientName))
            clean_ccepEventsToAnalyze = cat(1, clean_ccepEventsToAnalyze, ccepEventsToAnalyze(ei));
        end
    end
    ccepEventsToAnalyze = clean_ccepEventsToAnalyze;
end

function ccepEvent = initializeCCEP_Event()
    ccepEvent.patientName = '';
    ccepEvent.recordName = '';            
    ccepEvent.eventIdx = [];
    ccepEvent.globalStartSample = [];
    ccepEvent.signal = [];
    ccepEvent.driftAngle = 0;
    ccepEvent.waveletNorm_Max_Min_Avg_Std = [];
    ccepEvent.stimMontageName = '';
    ccepEvent.responseChannel = '';

    %estimated epileptogenicity
    ccepEvent.zones.pi = 0;
    ccepEvent.zones.ei = 0;
    %expert marked epileptogenicity, based on spontaneously occurring biomarkers  
    ccepEvent.zones.soz = 0;
    ccepEvent.zones.irritativeArea = 0;
    ccepEvent.zones.epilepticPatterns = 0;
    %automatically detected epileptogenicity, based on spontaneously occurring biomarkers           
    ccepEvent.zones.iesZone = 0;
    ccepEvent.zones.hfoZone = 0;
    ccepEvent.zones.iesHFO_Zone = 0;
    ccepEvent.zones.isolHFO_Zone = 0;
    %CCEP Components analysis
    ccepEvent.zones.ecZone = 0;
    ccepEvent.zones.lcZone = 0;
    
    ccepEvent.detectedBiomarkers = [];
    ccepEvent.mpResult = [];
    ccepEvent.components.early = [];
    ccepEvent.components.early.biomarkers.HFO = [];
    ccepEvent.components.early.biomarkers.iesHFO = [];
    ccepEvent.components.early.biomarkers.isolHFO = [];
    ccepEvent.components.early.biomarkers.IES = [];

    ccepEvent.components.late = [];
    ccepEvent.components.late.biomarkers.HFO = [];
    ccepEvent.components.late.biomarkers.iesHFO = [];
    ccepEvent.components.late.biomarkers.isolHFO = [];
    ccepEvent.components.late.biomarkers.IES = [];

    ccepEvent.components.post = [];
    ccepEvent.components.post.biomarkers.HFO = [];
    ccepEvent.components.post.biomarkers.iesHFO = [];
    ccepEvent.components.post.biomarkers.isolHFO = [];
    ccepEvent.components.post.biomarkers.IES = [];
end

function spectralPeak = fftSpectralPeak(signal, fs)
%     signalCopy = signal;
%     signalCopy = (signalCopy-mean(signalCopy))';
%     signalWS = signalCopy;
%     %dt = 1/fs;
%     N = size(signalWS, 1);
%     dF = fs/N;
%     f = (-fs/2:dF:fs/2-dF)';
%     %time = dt*(0:N-1)';
%     
%     spektrum = fftshift(fft(signalWS));
%     fReal = f( f > 0);
%     spektrumReal = spektrum(f>0);
%     [maxVal maxIdx] = max(spektrumReal);
%     spectralPeak.f = abs(fReal(maxIdx));
%     spectralPeak.p = abs(spektrumReal(maxIdx));
%     %signalWS = ifft(ifftshift(spektrum)); %inverse ifft
    
    lpad = 10*fs;
    xdft = fft(signal, lpad);
    xdft = xdft(1:lpad/2+1);            % Because the signal is real-valued, use only the positive frequencies from the DFT to estimate the amplitude
    xdft = xdft/length(signal);         % Scale the DFT by the length of the input signal
    xdft(2:end-1) = 2*xdft(2:end-1);    % multiply all frequencies except 0 and the Nyquist by 2
    xdft = real(xdft);
    freq = 0:fs/lpad:fs/2;
    
    [maxVal maxIdx] = max(xdft);
    spectralPeak.f = freq(maxIdx);
    spectralPeak.p = xdft(maxIdx)*xdft(maxIdx);
end

function bandStoppedSignal = fftBandStop(signal, fs, wA, wB)
    signal = signal';
    signalWS = signal;
    
    %wdw = hanning(length(signalWS));
    windowdWS = signalWS;%.*wdw;
    spektrum = fftshift(fft(windowdWS));

    N = length(spektrum);
    dF = fs/length(spektrum);
    f = (-fs/2:dF:fs/2-dF)';
    BSF = (abs(f) > wA) & (abs(f) < wB);

    spektrum = BSF.*spektrum;
    windowdWS = ifft(ifftshift(spektrum)); %inverse ifft

    windowdWS = real(windowdWS);
    bandStoppedSignal = signal-windowdWS;
    bandStoppedSignal = transpose(bandStoppedSignal);
end