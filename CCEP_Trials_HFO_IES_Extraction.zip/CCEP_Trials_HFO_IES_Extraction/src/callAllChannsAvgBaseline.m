function callAllChannsAvgBaseline(patientsAndRecords, excludeChannels)
    for patIdx = 1:size(patientsAndRecords,2)
        patientName = patientsAndRecords{patIdx}{1};
        baselines = [];
        badChannels = patientsAndRecords{patIdx}{4};
        whiteMatterChannels = readWhiteMatterChannels(patientName)';
        piChannels = getChannelsWithPI(patientName);
        badChannels = cleanChannelList(badChannels);
        whiteMatterChannels = cleanChannelList(whiteMatterChannels);
        piChannels = cleanChannelList(piChannels);

        for recIdx = 0:patientsAndRecords{patIdx}{3}
            suffix = strcat('_000', num2str(recIdx));
            if(recIdx > 9)
                suffix = strcat('_00', num2str(recIdx));
            end

            recordName = strcat(patientsAndRecords{patIdx}{2}, suffix);
            recordPath = strcat('F:\CCEP_Data\', patientsAndRecords{patIdx}{1}, '\CCEP_EEG\', patientsAndRecords{patIdx}{2}, suffix, '.vhdr')

            plotsDir = strcat('..\Plots\', patientName, '\', patientsAndRecords{patIdx}{1}, '_', patientsAndRecords{patIdx}{2}, suffix, '\');
            mkdir(plotsDir);

            cfg = [];
            cfg.dataset = recordPath;

            %read eeg data
            data_eeg        = ft_preprocessing(cfg);
            data_eeg.label = cleanChannelList(data_eeg.label);
            samplingRate = data_eeg.fsample;
            if samplingRate < 2000
                stop = 1;
            end

            % read marks
            cfg.trialdef.eventtype = 'Stimulus';
            cfg_ccep_trial = ft_definetrial(cfg);

            allLabels = data_eeg.label;
            selectedEEG_Labels = selectChannelsToProcess(allLabels, piChannels, excludeChannels, badChannels, whiteMatterChannels);    

            %Filter
            order = 32;
            filterDelay = order/2;
            h = fir1(order/2, [0.5/(samplingRate/2) 45/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
            filteredEEGData = cell(length(data_eeg.label), 1);
            for i = 1:length(data_eeg.label)
                filtSignal = filter(h, 1, flip(data_eeg.trial{1}(i,:)));
                filtSignal = filter(h, 1, flip(filtSignal));
                filtSignal(1:filterDelay) = filtSignal(filterDelay+1);
                filtSignal(end-filterDelay:end) = filtSignal(end-filterDelay-1);
                filteredEEGData{i} = filtSignal;
            end

            nrChannels = length(selectedEEG_Labels);
            for chIdx = 1:nrChannels
                channName = selectedEEG_Labels{chIdx};
                ccepEventsToAnalyze = [];        
                ccepEventsToAnalyze = loadProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName);
                ccepEventsToAnalyze = getAllChannsAvgBaseline(ccepEventsToAnalyze, samplingRate, channName, allLabels, selectedEEG_Labels, filteredEEGData);
                saveProcessedData('CCEP_TRIALS_PLUS_HFO_IES_PLUS_BL', patientName, recordName, channName, ccepEventsToAnalyze);
                %deleteProcessedData('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName);
            end          
        end
    end
end

function channList = cleanChannelList(channList)
    channList= strrep(channList, '_', '');
    channList = strrep(channList, '-', '');
end

function ccepEventsToAnalyze = getAllChannsAvgBaseline(ccepEventsToAnalyze, samplingRate, channName, allLabels, selectedEEG_Labels, filteredEEGData)
    
    fs = samplingRate;
    selChanns = [];
    for i = 1:length(allLabels)
       chn = allLabels{i};
       if sum(strcmp(selectedEEG_Labels, chn)) > 0
           selChanns = cat(1,selChanns,i);
       end
    end
    allChannsSum = [];
    for schi = 1:length(selChanns)
        sig = filteredEEGData{selChanns(schi)};
        if isempty(allChannsSum)
            allChannsSum = sig;
        else
            allChannsSum = allChannsSum + sig;
        end
    end
    nrSummedChanns = length(selChanns);
    nrEvents = size(ccepEventsToAnalyze,1);
    
    for ei = 1:nrEvents                    
        responseChannel = ccepEventsToAnalyze{ei}.responseChannel;
        stimMontage = ccepEventsToAnalyze{ei}.stimMontageName;
        channOneStim = stimMontage(1:strfind(stimMontage,'-')-1);
        channTwoStim = stimMontage(strfind(stimMontage,'-')+1:end);
                        
        stimPulseStart = ccepEventsToAnalyze{ei}.globalStartSample;
        stimulusTrialEnd = stimPulseStart + length(ccepEventsToAnalyze{ei}.signal);        %this sample is actually the end of stimulus artefact

        %baseline
        bss = stimPulseStart + 0.1*fs;
        bes = stimulusTrialEnd;
        blSignal = allChannsSum(bss:bes);
        %Substract stimulation  channel A
        fileChIdx = find(strcmp(allLabels, channOneStim));
        blSignal = blSignal - filteredEEGData{fileChIdx}(bss:bes);
        %Substract stimulation  channel B
        fileChIdx = find(strcmp(allLabels, channTwoStim));
        blSignal = blSignal - filteredEEGData{fileChIdx}(bss:bes);
        %Substract response channel
        fileChIdx = find(strcmp(allLabels, responseChannel));
        blSignal = blSignal - filteredEEGData{fileChIdx}(bss:bes);
        blSignal = detrend(blSignal/(nrSummedChanns-3));
        baseline = {responseChannel, mean(blSignal), median(blSignal), std(blSignal)};           
        ccepEventsToAnalyze{ei}.baseline = baseline;
        
        %add thsi entry to the structure
        ccepEventsToAnalyze{ei}.components.early.info = initializeComponent();
        ccepEventsToAnalyze{ei}.components.late.info = initializeComponent();
        ccepEventsToAnalyze{ei}.components.post.info = initializeComponent();
        
        ccepEventsToAnalyze{ei}.components.early.features = [];
        ccepEventsToAnalyze{ei}.components.late.features = [];
        ccepEventsToAnalyze{ei}.components.post.features = [];
    end
end

function component = initializeComponent()
    component.exists = 0;
    component.nrWaves = 0;
    component.spectralPeak = 0;    
    component.startSec = 0;
    component.endSec = 0;
    component.durationSec = 0;        
end

function saveProcessedData(type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    mkdir(patientRecordPath);
    save(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function ccepEventsToAnalyze = loadProcessedData(type, patientName, recordName, channName)
    ccepEventsToAnalyze = [];
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    load(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function deleteProcessedData(type, patientName, recordName, channName)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    delete(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'));
end

function whiteMatterChannels = readWhiteMatterChannels(patientName)
    zoiFileName = strcat('F:\CCEP_Data\', patientName, '\', patientName, '_CorticalChannels.txt');
    FID=fopen(zoiFileName);
    header = textscan(FID,'%s%s', 1, 'Delimiter','\t');
    corticChanns = textscan(FID, '%s%d', 'HeaderLines', 1, 'CollectOutput', 0);
    fclose(FID);
    whiteMatterChannels = corticChanns{1}(not(corticChanns{2}));
end

function channNamesPI = getChannelsWithPI(patientName)

    %Read the file
    seizurePropagationsFN = strcat('F:\CCEP_Data\', patientName, '\', patientName, '_Propagations.txt');
    piFile = tdfread(seizurePropagationsFN,'\t');
    szrData = struct2cell(piFile);
    dataLabels = szrData{1,1};

    %get and correct channel names
    channNamesPI = cell(size(szrData{1},1)-3,1);
    for i = 1:size(channNamesPI,1)
        channNamesPI{i} = dataLabels(i,:);
        channNamesPI{i} = strrep(channNamesPI{i},' ', '');
        channNamesPI{i} = strrep(channNamesPI{i},'\t', '');
    end   
end

function selectedEEG_Labels = selectChannelsToProcess(eegLabels, piChannels, excludeChannels, badChannels, whiteMatterChannels)

    %select channels to ignore
    nonPI_Channels = {};
    schi = 1;
    for chi = 1:length(eegLabels)
        chName = eegLabels{chi};
        if sum(strcmp(piChannels, chName)) == 0
            nonPI_Channels{schi} = chName;
            schi = schi+1;
        end
    end 
    ignoreChannels = cat(2, excludeChannels, badChannels, whiteMatterChannels, nonPI_Channels);

    %select channels to process
    selectedEEG_Labels = {};
    schi = 1;
    for chi = 1:length(eegLabels)
        chName = eegLabels{chi};
        if sum(strcmp(ignoreChannels, chName)) == 0
            selectedEEG_Labels{schi} = chName;
            schi = schi+1;
        end
    end 
end