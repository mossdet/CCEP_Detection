function ccepEventsToAnalyze = getHFO_Analysis(samplingRate, ccepEventsToAnalyze, hfoDetectorFolder, plotCCEP_DetectionsOK, plotsDir)
         
    eventsSamplesStartEnd = [];
    hfoSignal = [];
    hfoSignal = double(hfoSignal);

    %iterate through all the CCEPs
    for respIdx = 1:size(ccepEventsToAnalyze,1)
        respIdx
        response = ccepEventsToAnalyze{respIdx}.signal;
        eventStartSampleInSegment = length(hfoSignal)+1;
        eventEndSampleInSegment = eventStartSampleInSegment + length(response) - 1;                
        eventsSamplesStartEnd = cat(1, eventsSamplesStartEnd, [eventStartSampleInSegment eventEndSampleInSegment]);
        hfoSignal = cat(2, hfoSignal, response);

        stimMontageName = ccepEventsToAnalyze{respIdx}.stimMontageName;
        responseChannName = ccepEventsToAnalyze{respIdx}.responseChannel;
        lastSameChannStimulus = 0;
        if(respIdx+1 <= size(ccepEventsToAnalyze,1))
            nextStimMontageName = ccepEventsToAnalyze{respIdx+1}.stimMontageName;
            lastSameChannStimulus = not(strcmp(stimMontageName,nextStimMontageName));
        end
        
        if lastSameChannStimulus
            stimuliSampleStart = eventsSamplesStartEnd(:,1);
            hfoDetections = detectHFO(hfoDetectorFolder, hfoSignal, samplingRate, stimuliSampleStart, stimMontageName, responseChannName, plotsDir, plotCCEP_DetectionsOK);
            
            waveletNorm_Max_Min_Avg_Std = [];
            if plotCCEP_DetectionsOK > 0
                [cfs,frq, coi] = cwt((hfoSignal), 'amor', samplingRate, 'FrequencyLimits',[60 600]);
                waveletNorm_Max_Min_Avg_Std = [max(abs(cfs),[],'all') min(abs(cfs),[],'all') mean(abs(cfs),'all') std(abs(cfs),0,'all')];
            end
            
            nrCCEP_EventsAnalyzed = size(eventsSamplesStartEnd,1);
            for i = 1:nrCCEP_EventsAnalyzed
                ccepEventHFO_Detections = [];
                if not(isempty(hfoDetections))
                    selectedIndices = (hfoDetections.startSample >= eventsSamplesStartEnd(i,1)) & (hfoDetections.endSample <= eventsSamplesStartEnd(i,2));
                    if sum(selectedIndices > 0) > 0
                        ccepEventHFO_Detections = [hfoDetections.mark(selectedIndices); hfoDetections.startSample(selectedIndices); hfoDetections.endSample(selectedIndices)];
                        ccepEventHFO_Detections(2,:) = ccepEventHFO_Detections(2,:) -  (eventsSamplesStartEnd(i,1)-1);  %get sample index for ccep event
                        ccepEventHFO_Detections(3,:) = ccepEventHFO_Detections(3,:) -  (eventsSamplesStartEnd(i,1)-1);  %get sample index for ccep event
                    end
                end
                ccepEventIdx = respIdx - (nrCCEP_EventsAnalyzed-i);
                ccepEventsToAnalyze{ccepEventIdx}.detectedBiomarkers = ccepEventHFO_Detections;
                ccepEventsToAnalyze{ccepEventIdx}.waveletNorm_Max_Min_Avg_Std = waveletNorm_Max_Min_Avg_Std;
            end
             
            hfoSignal = [];
            eventsSamplesStartEnd = [];
            nrCCEP_EventsAnalyzed = 0;
        end
    end
end


function hfoDetections = detectHFO(hfoDetectorFolder, hfoSignal, samplingRate, stimuliSampleStart, stimMontageName, responseChannel, plotsDir, plotCCEP_DetectionsOK)
%     stimMontageName = strrep(stimMontageName, '_', '');
%     stimMontageName = strrep(stimMontageName, '-', '');
%     stimMontageName = strrep(stimMontageName, ' ', '');
% 
%     responseChannel = strrep(responseChannel, '_', '');
%     responseChannel = strrep(responseChannel, '-', '');
%     responseChannel = strrep(responseChannel, ' ', '');
        
    %detect the HFO
    hfoDetections = [];
    %hfoDetectorFolder = 'D:\MATLAB\Projects\CCEP_ver3\MOSSDET_c\';
    hfoSignal = transpose(hfoSignal);
    savedSignalPath = strcat(hfoDetectorFolder, stimMontageName, '_', responseChannel, '.mat');
    save(savedSignalPath,'hfoSignal');
    hfoDetectorOutputFolder = strrep(hfoDetectorFolder, "\", "\\");
    hfoDetectorOutputFolder = strcat(hfoDetectorOutputFolder, stimMontageName, '_', responseChannel,'\\');
    
    clearOutputDir(hfoDetectorOutputFolder);
    
    mossdetVariables.exePath = strcat(hfoDetectorFolder, 'MOSSDET_c.exe');
    mossdetVariables.signalFilePath = savedSignalPath;
    mossdetVariables.decFunctionsPath = hfoDetectorFolder;
    mossdetVariables.outputPath = hfoDetectorOutputFolder;
    mossdetVariables.startTime = 0;
    mossdetVariables.endTime = 60*60*243*65;    
    mossdetVariables.samplingRate = samplingRate;
    mossdetVariables.eoiType = 'HFO+IES'; 'HFO+IES';'SleepSpindles';
    mossdetVariables.verbose = 0;
    mossdetVariables.saveDetections = 1;

    command = strcat(mossdetVariables.exePath, {' '},...
                     mossdetVariables.signalFilePath, {' '},...
                     mossdetVariables.decFunctionsPath, {' '}, ...
                     mossdetVariables.outputPath, {' '},...
                     num2str(mossdetVariables.startTime), {' '},...
                     num2str(mossdetVariables.endTime), {' '},...
                     num2str(mossdetVariables.samplingRate), {' '},...
                     mossdetVariables.eoiType, {' '},...
                     num2str(mossdetVariables.verbose), {' '},...
                     num2str(mossdetVariables.saveDetections));

    system(command{1})
    
    %read detections from generated text files instead of generating a
    %matlab file, which fails often
    MOSSDET_Detections = [];
    MOSSDET_Detections = readDetections(mossdetVariables.outputPath, strcat(stimMontageName, '_', responseChannel), 'Ripple', MOSSDET_Detections);
    MOSSDET_Detections = readDetections(mossdetVariables.outputPath, strcat(stimMontageName, '_', responseChannel), 'FastRipple', MOSSDET_Detections);
    MOSSDET_Detections = readDetections(mossdetVariables.outputPath, strcat(stimMontageName, '_', responseChannel), 'Spike', MOSSDET_Detections);

    delete(mossdetVariables.signalFilePath);
    clearOutputDir(mossdetVariables.outputPath);
    MOSSDET_Detections = getIES_CoincidentHFO(MOSSDET_Detections);
    
    if isempty(MOSSDET_Detections)
        hfoDetections.mark = [];
        hfoDetections.startSample = [];
        hfoDetections.endSample = []; 
    else
        [~,idx] = sort(MOSSDET_Detections(2,:)); % sort just the second row
        MOSSDET_Detections = MOSSDET_Detections(:,idx);   % sort the whole matrix using the sort indices

        hfoDetections.mark = int64(MOSSDET_Detections(1,:));
        detectionStartTimesLocal = MOSSDET_Detections(2,:);
        detectionEndTimesLocal = MOSSDET_Detections(3,:);
        detectionStartSamplesLocal = int64(double(detectionStartTimesLocal).*double(samplingRate));
        detectionEndSamplesLocal = int64(double(detectionEndTimesLocal).*double(samplingRate));
        hfoDetections.startSample = detectionStartSamplesLocal;
        hfoDetections.endSample = detectionEndSamplesLocal; 
    end
        
    % plot the events being detected on the responses generated by
    % a single stimulated channel
    plotOkB = plotCCEP_DetectionsOK;
    if plotOkB > 0
        
        
        order = 128;
        filterDelay = order/2;
        h = fir1(order/2, [80/(samplingRate/2) 500/(samplingRate/2)], 'bandpass'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1'
        filteredHFO_Signal = filter(h, 1, flip(hfoSignal));
        filteredHFO_Signal = filter(h, 1, flip(filteredHFO_Signal));
        filteredHFO_Signal(1:filterDelay) = filteredHFO_Signal(filterDelay+1);
        filteredHFO_Signal(end-filterDelay:end) = filteredHFO_Signal(end-filterDelay-1);
        
        time = 0:length(hfoSignal)-1;
        time = time/samplingRate;
        
        close all;
        figName = strcat('Stimulus_', stimMontageName, '_Response_', responseChannel);
        f2 = figure('Name', figName,'NumberTitle','off', 'Color', 'w');

        subplot(4,1,1)
        hfoPlot = plot(time, filteredHFO_Signal,'k','LineWidth',0.01); hold on;
        hfoPlot.Color(4) = 0.2;
        nrEOI = 0;
        for detIdx = 1:length(hfoDetections.mark)
            allHFO = hfoDetections.mark(detIdx) == 1 || hfoDetections.mark(detIdx) == 2;
            if allHFO
                startSample = detectionStartSamplesLocal(detIdx);
                endSample = detectionEndSamplesLocal(detIdx);
                plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'r','LineWidth',0.01); hold on;
                nrEOI = nrEOI+1;
            end
        end
        for smi = 1:size(stimuliSampleStart, 1)
            vline(stimuliSampleStart(smi)/samplingRate,'g');
            vline(stimuliSampleStart(smi)/samplingRate + 1,'y');
        end
        xlim([min(time) max(time)])
        title('all HFO', 'FontSize',20)
        legend('Band-Passed (80-500 Hz)', strcat('HFO Detections (', num2str(nrEOI), ')'), 'FontSize',16)

        subplot(4,1,2)
        hfoPlot = plot(time, filteredHFO_Signal,'k','LineWidth',0.01); hold on;
        hfoPlot.Color(4) = 0.2;
        nrEOI = 0;
        for detIdx = 1:length(hfoDetections.mark)
            iesHFO = hfoDetections.mark(detIdx) == 4 || hfoDetections.mark(detIdx) == 5;
            if iesHFO
                startSample = detectionStartSamplesLocal(detIdx);
                endSample = detectionEndSamplesLocal(detIdx);
                plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'r','LineWidth',0.01); hold on;
                nrEOI = nrEOI+1;
            end
        end
        for smi = 1:size(stimuliSampleStart, 1)
            vline(stimuliSampleStart(smi)/samplingRate,'g');
            vline(stimuliSampleStart(smi)/samplingRate + 1,'y');
        end
        xlim([min(time) max(time)])
        title('IES-HFO', 'FontSize',20)
        legend('Band-Passed (80-500 Hz)', strcat('IES-HFO Detections (', num2str(nrEOI), ')'), 'FontSize',16)

        subplot(4,1,3)
        hfoPlot = plot(time, hfoSignal,'k','LineWidth',0.01); hold on;
        hfoPlot.Color(4) = 0.2;
        nrEOI = 0;
        for detIdx = 1:length(hfoDetections.mark)
            ies = hfoDetections.mark(detIdx) == 3;
            if ies
                startSample = detectionStartSamplesLocal(detIdx);
                endSample = detectionEndSamplesLocal(detIdx);
                plot(time(startSample:endSample), hfoSignal(startSample:endSample),'r','LineWidth',0.01); hold on;
                nrEOI = nrEOI+1;
            end
        end
        for smi = 1:size(stimuliSampleStart, 1)
            vline(stimuliSampleStart(smi)/samplingRate,'g');
            vline(stimuliSampleStart(smi)/samplingRate + 1,'y');
        end
        xlim([min(time) max(time)])
        title('IES', 'FontSize',20)
        legend('Raw',  strcat('IES Detections (', num2str(nrEOI), ')'), 'FontSize',16)
        xlabel('Time (s)')
        %ylabel('Amplitude')
        
        
        %Plot wavelet decomposition
        [minPossFreq,maxPossFreq] = cwtfreqbounds(length(hfoSignal), samplingRate);
        minFreq = 60;
        maxFreq = 600;
        if (minPossFreq > minFreq) || (maxPossFreq < maxFreq) 
            stop = 1;
        end
        [cfs,frq, coi] = cwt(hfoSignal, 'amor', samplingRate, 'FrequencyLimits',[minFreq maxFreq]);
        absCFS = abs(cfs);
        normCFS = (absCFS - mean(absCFS,'all'))/std(absCFS,0,'all');
        subplot(4,1,4)
        contour(time,frq,abs(normCFS), 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
        title('Wavelet Power Spectrum')
        %colorbar
        xlabel('Time (s)')
        ylabel('Frequency (Hz)')
        set(gca,'yscale','log')
        set(gcf,'Colormap',jet)
        set(gca,'XLim',[min(time) max(time)], 'YLim',[min(frq) max(frq)],'XGrid','On', 'YGrid','On')
       
        set(gcf, 'Position', get(0, 'Screensize'));
                
        plotResponsesDir = strcat(plotsDir, 'DetectedEOI\', responseChannel, '\');
        mkdir(plotResponsesDir)
        figOneFileName = strcat(plotResponsesDir, 'Stimulus_', stimMontageName, '_Response_', responseChannel);
        savefig(f2, figOneFileName, 'compact');
        hgexport(gcf, figOneFileName, hgexport('factorystyle'), 'Format', 'jpeg');
        close();
        %plotWaveletDecomposition(hfoSignal, filteredHFO_Signal, samplingRate, time, hfoDetections, stimuliSampleStart, stimMontageName, responseChannel);
    end

end

function clearOutputDir(hfoDetectorOutputFolder)
    dirO = strcat(strrep(hfoDetectorOutputFolder, "\\", "\"));
    A = dir(dirO);
    fclose('all');
    if not(isempty(A))
        rmdir(dirO, 's')
    end
end
function MOSSDET_Detections = readDetections(outputFolder, channelsInfo, eventName, MOSSDET_Detections)

    outputFolder = strrep(outputFolder, '\\', '\');
    detectionOutFilename = strcat(outputFolder, 'MOSSDET_Output\', channelsInfo, '\DetectionFiles\', channelsInfo, '_', eventName, 'DetectionsAndFeatures.txt');
    if not(isfile(detectionOutFilename))
        detectionOutFilename
        stop = 1;
        return;
    end
    %Description	ChannelName	StartTime(s)	EndTime(s)	MaxEventAmplitude	MaxEventPower	MaxEventSpectralPeak (Hz)	AvgBackgroundAmplitude	AvgBackgroundPower	BackgroundStdDev
    [Description, ChannelName, StartTime, EndTime, MaxEventAmplitude, MaxEventPower, MaxEventSpectralPeak, AvgBackgroundAmplitude, AvgBackgroundPower, BackgroundStdDev] =...   
    textread(detectionOutFilename, '%s\t%s\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f', 'headerlines', 1);

    delete(detectionOutFilename);
    mark = 0;
    if strcmp(eventName, 'Ripple')
        mark = 1;
    elseif strcmp(eventName, 'FastRipple')
        mark = 2;
    elseif strcmp(eventName, 'Spike')
        mark = 3;    
    end
    marksVec = zeros(1, length(Description)) + mark;
    StartTime = transpose(StartTime);
    EndTime = transpose(EndTime);
    
    detectionsMatrix = [];
    if isempty(MOSSDET_Detections)
        detectionsMatrix = cat(1, detectionsMatrix, marksVec);
        detectionsMatrix = cat(1, detectionsMatrix, StartTime);
        detectionsMatrix = cat(1, detectionsMatrix, EndTime);
    else
        detectionsMatrix = cat(1, detectionsMatrix, cat(2, MOSSDET_Detections(1, :), marksVec));
        detectionsMatrix = cat(1, detectionsMatrix, cat(2, MOSSDET_Detections(2, :), StartTime));
        detectionsMatrix = cat(1, detectionsMatrix, cat(2, MOSSDET_Detections(3, :), EndTime));
    end
    MOSSDET_Detections = detectionsMatrix;
end

function MOSSDET_Detections = getIES_CoincidentHFO(MOSSDET_Detections)
    nrDetections = size(MOSSDET_Detections, 2);
    
    for fdi = 1:nrDetections    %iterate through HFO
        iesCoincidence = 0;
        fdType = MOSSDET_Detections(1, fdi);
        fdStart = MOSSDET_Detections(2, fdi);
        fdEnd = MOSSDET_Detections(3, fdi);
        fdDuration = fdEnd - fdStart;
        
        if(fdType == 3)
            continue;
        end
        
        for sdi = 1:nrDetections    %iterate through IES
            if (fdi == sdi || MOSSDET_Detections(1, sdi) ~= 3)
                continue;
            end
            sdStart = MOSSDET_Detections(2, sdi);
            sdEnd = MOSSDET_Detections(3, sdi);
            sdDuration = sdEnd - sdStart;
            overlapTime = getEventsOverlap(fdStart, fdEnd, sdStart, sdEnd);
            overlapPerc = 100*(overlapTime / fdDuration);
            if (100 * (overlapTime / sdDuration) > overlapPerc)
                overlapPerc = 100 * (overlapTime / sdDuration);
            end
            if overlapPerc > 50.0
                iesCoincidence = 1;
                break;
            end
        end
        
        %     - All Ripples     (1) -> any Ripple
        %     - All FR          (2) -> any FR
        %     - All IES         (3) -> any IES

        %     - IES_Ripples     (4) -> any Ripple coinciding with a IES
        %     - IES_FR          (5) -> any FR coinciding with a IES
        %     - isolRipples     (6) -> any Ripple not coinciding with IES
        %     - isolFR          (7) -> any FR not coinciding with IES

        if fdType == 1
            if iesCoincidence > 0
                MOSSDET_Detections = cat(2, MOSSDET_Detections, [4; fdStart; fdEnd]);
            else
                MOSSDET_Detections = cat(2, MOSSDET_Detections, [6; fdStart; fdEnd]);
            end
        elseif fdType == 2 
            if iesCoincidence > 0
                MOSSDET_Detections = cat(2, MOSSDET_Detections, [5; fdStart; fdEnd]);
            else
                MOSSDET_Detections = cat(2, MOSSDET_Detections, [7; fdStart; fdEnd]);
            end
        end
    end
end

function overlapTime = getEventsOverlap(feStart, feEnd, seStart, seEnd)
    overlapTime = 0;
    feDuration = feEnd - feStart;
    seDuration = seEnd - seStart;
    
    if feStart <= seStart && feEnd >= seEnd % first fully encompassing second
        overlapTime = seDuration;        
    elseif seStart <= feStart && seEnd >= feEnd % second fully encompassing first
        overlapTime = feDuration;        
    elseif (feStart <= seStart && feEnd >= seStart && feEnd <= seEnd) %last part of first inside second
        overlapTime = feEnd - seStart;
    elseif (seStart <= feStart && seEnd >= feStart && seEnd <= feEnd) %last part of second inside first
        overlapTime = seEnd - feStart;
    else
        overlapTime = 0;
    end
end

function plotWaveletDecomposition(hfoSignal, filteredHFO_Signal, samplingRate, time, hfoDetections, stimuliSampleStart, stimMontageName, responseChannel)
    close all;
        
    [minPossFreq,maxPossFreq] = cwtfreqbounds(length(hfoSignal), samplingRate);
    minFreq = 60;
    maxFreq = 600;
    if (minPossFreq > minFreq) || (maxPossFreq < maxFreq) 
        stop = 1;
    end

    [cfs,frq, coi] = cwt(hfoSignal, 'amor', samplingRate, 'FrequencyLimits',[minFreq maxFreq]);
        
    figName = strcat('Stimulus_', stimMontageName, '_Response_', responseChannel);
    f2 = figure('Name', figName,'NumberTitle','off', 'Color', [1 1 1]);
    subplot(2,1,1)
    hfoPlot = plot(time, filteredHFO_Signal,'k','LineWidth',0.01); hold on;
    hfoPlot.Color(4) = 0.2;
    nrEOI = 0;
    for detIdx = 1:length(hfoDetections.mark)
        allHFO = hfoDetections.mark(detIdx) == 1 || hfoDetections.mark(detIdx) == 2;
        if allHFO
            startSample = hfoDetections.startSample(detIdx);
            endSample = hfoDetections.endSample(detIdx);
            plot(time(startSample:endSample), filteredHFO_Signal(startSample:endSample),'r','LineWidth',0.01); hold on;
            nrEOI = nrEOI+1;
        end
    end
    for smi = 1:size(stimuliSampleStart, 1)
        vline(stimuliSampleStart(smi)/samplingRate,'g');
        vline(stimuliSampleStart(smi)/samplingRate + 1,'y');
    end
    axis tight
    xlabel('Time (s)')
    ylabel('Amplitude')
    xlim([min(time) max(time)])
    title('all HFO', 'FontSize',20)
    legend('Band-Passed (80-500 Hz)', strcat('HFO Detections (', num2str(nrEOI), ')'), 'FontSize',16)
    
    
    subplot(2,1,2)
    contour(time,frq,abs(cfs), 'LineStyle','none', 'LineColor',[0 0 0], 'Fill','on')
    title('Wavelet Power Spectrum')
    colorbar
    %surface(time,frq,abs(cfs))
%     axis tight
%     shading flat
    xlabel('Time (s)')
    ylabel('Frequency (Hz)')
    set(gca,'yscale','log')
    set(gcf,'Colormap',jet)
    set(gca,'XLim',[min(time) max(time)], 'YLim',[min(frq) max(frq)],'XGrid','On', 'YGrid','On')
end

function y = notchFilter(hfoSignal, samplingRate)
    order = 32;
    filterDelay = order/2;
    h = fir1(order/2, [48/(samplingRate/2) 52/(samplingRate/2)], 'stop'); % 'low' | 'bandpass' | 'high' | 'stop' | 'DC-0' | 'DC-1' 
    stopSignal = filter(h, 1, flip(hfoSignal));
    stopSignal = filter(h, 1, flip(stopSignal));
    stopSignal(1:filterDelay) = stopSignal(filterDelay+1);
    stopSignal(end-filterDelay:end) = stopSignal(end-filterDelay-1);
    %y = stopSignal-hfoSignal;
    y = stopSignal;
    
% 	close all;
%     subplot(2,1,1)
%     plot(hfoSignal)
%     
%     subplot(2,1,2)
%     plot(y)
end
