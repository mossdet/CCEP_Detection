function getCCEP_Trials_HFO_IES(patientName, recordName, data_eeg, cfg_ccep_trial, selectedEEG_Labels, hfoDetectorFolder, plotsDir)
     
    nrChannels = length(selectedEEG_Labels);
    samplingRate = data_eeg.fsample;
    
    % stimEvents is a cell with columns: globalEventIndex, evStartSample, evEndSample, stimMontageName, durationsEC
    stimEvents = getStimulationEvents(cfg_ccep_trial.event, samplingRate, data_eeg.sampleinfo(2));
    stimEvents = removeArtefactualEvents(stimEvents);
    
    %Get signal segments to analyze and detect HFO and IES events
    plotTrialsSignals = 0;
    plotCCEP_DetectionsOK = 0;
    
    for chIdx = 1:nrChannels
        chIdx
        channName = selectedEEG_Labels{chIdx};
        fileChIdx = find(strcmp(data_eeg.label, channName));
        signal = data_eeg.trial{1}(fileChIdx,:);
        ccepEventsToAnalyze = [];
        %Save all valid CCEP trials to a cell filled with structures
        ccepEventsToAnalyze = getEEG_SegmentsToAnalyze(data_eeg, selectedEEG_Labels, stimEvents, patientName, recordName, signal, samplingRate, channName, plotTrialsSignals, plotsDir);
        saveChannelEvents('', patientName, recordName, channName, ccepEventsToAnalyze);
    end
    clear stimEvents
    clear data_eeg;
    
    parfor chIdx = 1:nrChannels
        chIdx
        channName = selectedEEG_Labels{chIdx};
        ccepEventsToAnalyze = [];
        ccepEventsToAnalyze = loadChannelEvents('', patientName, recordName, channName, ccepEventsToAnalyze);
        %Detect HFO and IES on the CCEPP trials
        ccepEventsToAnalyze = getHFO_Analysis(samplingRate, ccepEventsToAnalyze, hfoDetectorFolder, plotCCEP_DetectionsOK, plotsDir);
        saveChannelEvents('CCEP_TRIALS_PLUS_HFO_IES', patientName, recordName, channName, ccepEventsToAnalyze);
        deleteChannelEvents('', patientName, recordName, channName);
    end
end

function stimEvents = getStimulationEvents(allEvents, samplingRate, totalSamples)
    nrAllEvents = size(allEvents,2);
    
    nrIgnoredEvents = 0;
    stimEvents = {};
    for sti = 1:nrAllEvents
        mark = allEvents(sti).value;
        if not(isempty(mark)) && (contains(mark,'msec') || contains(mark,'igger'))
            stimStartSample = 0;
            stimEndSample = 0;
            trialEndSample = 0;
            
            if sti+2 <=nrAllEvents
                stimStartSample = allEvents(sti).sample;
                stimEndSample = allEvents(sti+1).sample;
                trialEndSample = allEvents(sti+2).sample;
            end

            stimDuration = (stimEndSample-stimStartSample)/samplingRate;
            eventDuration = (trialEndSample-stimStartSample)/samplingRate;
            if (stimStartSample > 0 && stimEndSample > 0 && trialEndSample > 0) && (stimDuration < 0.1) && (eventDuration >= 2.8 && eventDuration < 6)
                saveMark = '';
                if contains(allEvents(sti).value,'msec')
                    saveMark = allEvents(sti).value;
                elseif contains(allEvents(sti+1).value,'msec')
                    saveMark = allEvents(sti+1).value;
                else
                    continue;%stop = 1/0;
                end                          
      
                stimChannOneMarkEnd = strfind(saveMark,'-');
                stimChannTwoMarkEnd = strfind(saveMark,'_');
                channOneStim = saveMark(1:stimChannOneMarkEnd(1)-1);
                channTwoStim = saveMark(stimChannOneMarkEnd+1:stimChannTwoMarkEnd-1);
                channOneStim = erase(channOneStim,'_');
                channTwoStim = erase(channTwoStim,'_');                
                stimMontageName = strcat(channOneStim, '-', channTwoStim);
                stimEvents = cat(1, stimEvents, {sti, stimStartSample, stimEndSample, trialEndSample, channOneStim, channTwoStim, stimMontageName, eventDuration});
            else
                stop = 1;
                nrIgnoredEvents = nrIgnoredEvents+1;
                %erros('Wrong event length');
            end

        end
    end
end

function depuratedStimEvents = removeArtefactualEvents(stimEvents)
%remove events after and before changing the stimulation channel, thsi is
%needed because of the artefact produced by the switch matrix
    nrEvents = size(stimEvents, 1);
    deleteEvents= zeros(1, nrEvents);
    for ei = 2:nrEvents-1
        prevChann = stimEvents{ei-1, 7};
        currChann = stimEvents{ei, 7};
        nextChann = stimEvents{ei+1, 7};
        
        if not(strcmp(currChann, prevChann))
            deleteEvents(ei-1) = 1;
            deleteEvents(ei) = 1;
        end
        
        if not(strcmp(currChann, nextChann))
            deleteEvents(ei) = 1;
            deleteEvents(ei+1) = 1;
        end
    end
    
    depuratedStimEvents = {};
    for ei = 1:nrEvents
        if deleteEvents(ei) == 0
            depuratedStimEvents = cat(1, depuratedStimEvents, stimEvents(ei, :));
        end
    end
end

function saveChannelEvents(type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    mkdir(patientRecordPath);
    save(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function ccepEventsToAnalyze = loadChannelEvents(type, patientName, recordName, channName, ccepEventsToAnalyze)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    load(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'), 'ccepEventsToAnalyze');
end

function deleteChannelEvents(type, patientName, recordName, channName)
    patientRecordPath = strcat('..\Analyses', type, '\', patientName, '\', recordName, '\');
    patientRecordPath = strcat('I:\CCEP_Data\CCEP_Detections\Analyses', type, '\', patientName, '\', recordName, '\');
    delete(strcat(patientRecordPath, channName, '_', type, '_Analyzed_CCEP_Events.mat'));
end
